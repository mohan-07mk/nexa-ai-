// ==============================================================================
// NEXA AI — CALENDAR SERVICE (LOCAL & GOOGLE CALENDAR API)
// Handles event management, Google OAuth Calendar sync, and Supabase persistence
// ==============================================================================

import { supabase, isSupabaseConfigured } from './supabaseClient.js';

export async function getGoogleCalendarToken() {
  if (!isSupabaseConfigured() || !supabase) return null;
  try {
    const { data: { session } } = await supabase.auth.getSession();
    return session?.provider_token || null;
  } catch (err) {
    return null;
  }
}

// Fetch events from Google Calendar if provider token is active
export async function fetchGoogleCalendarEvents() {
  const token = await getGoogleCalendarToken();
  if (!token) return null;

  try {
    const timeMin = new Date().toISOString();
    const res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${timeMin}&singleEvents=true&orderBy=startTime&maxResults=20`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (res.ok) {
      const data = await res.json();
      return (data.items || []).map((ev) => ({
        id: ev.id,
        title: ev.summary || 'Google Calendar Event',
        date: ev.start?.dateTime?.split('T')[0] || ev.start?.date || '',
        time: ev.start?.dateTime ? ev.start.dateTime.split('T')[1].slice(0, 5) : '09:00',
        cat: 'Google Calendar',
        googleId: ev.id
      }));
    }
  } catch (err) {
    console.warn('Failed to fetch Google Calendar events:', err);
  }
  return null;
}

// Create event in Google Calendar if connected
export async function createGoogleCalendarEvent(event) {
  const token = await getGoogleCalendarToken();
  if (!token) return null;

  try {
    const startIso = `${event.date}T${event.time || '10:00'}:00`;
    const startDate = new Date(startIso);
    const endDate = new Date(startDate.getTime() + 60 * 60 * 1000); // 1 hour duration

    const res = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        summary: event.title,
        description: `Created by NEXA AI · Category: ${event.cat || 'Work'}`,
        start: { dateTime: startDate.toISOString() },
        end: { dateTime: endDate.toISOString() }
      })
    });

    if (res.ok) {
      const gEv = await res.json();
      return gEv.id;
    }
  } catch (err) {
    console.warn('Failed to sync event to Google Calendar:', err);
  }
  return null;
}

// Sync event to Supabase
export async function saveCalendarEventToCloud(event) {
  if (!isSupabaseConfigured() || !supabase) return;
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase.from('calendar_events').upsert({
      id: typeof event.id === 'string' && event.id.includes('-') ? event.id : undefined,
      user_id: user.id,
      title: event.title,
      date: event.date,
      time: event.time || '10:00',
      category: event.cat || 'Work',
      google_event_id: event.googleId || null
    });
  } catch (err) {
    console.warn('Cloud calendar sync error:', err);
  }
}
