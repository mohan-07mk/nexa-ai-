import {useState,useEffect} from 'react';
export default function useStore(k,d){
  const [v,s]=useState(()=>{try{const x=localStorage.getItem(k);return x?JSON.parse(x):d}catch(e){return d}});
  useEffect(()=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}},[v]);
  return [v,s];
}
