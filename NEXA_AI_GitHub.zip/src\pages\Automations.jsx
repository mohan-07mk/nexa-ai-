import React, { useState } from 'react';
import { Ic } from '../components/Icon';
import { Empty } from '../components/ui';
import { fmt } from '../utils/helpers';
import useStore from '../hooks/useStore';
import { runAutomationNow, saveAutomationToCloud } from '../services/automationService';

export default function Automations({ autos, setAutos, log }) {
  const [f, setF] = useState({ name: "", trigger: "Daily", time: "07:00", action: "Show daily plan" });
  const [hist, setHist] = useStore("nexa.autolog", []);
  const [runningId, setRunningId] = useState(null);

  const add = async (e) => {
    e.preventDefault();
    if (!f.name.trim()) return;

    const newAuto = {
      ...f,
      id: Date.now(),
      on: true,
      last: "Never"
    };

    setAutos(a => [...a, newAuto]);
    await saveAutomationToCloud(newAuto);
    log("Automation created", f.name);
    setF({ ...f, name: "" });
  };

  const run = async (a) => {
    setRunningId(a.id);
    try {
      const res = await runAutomationNow(a);
      const at = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      setAutos(x => x.map(y => y.id === a.id ? { ...y, last: `Today ${at} (Executed)` } : y));
      setHist(h => [{ id: Date.now(), t: `${a.name} · ${res.summary || 'Executed'}` }, ...h].slice(0, 20));
      log("Automation executed", `${a.name} · ${res.summary || 'Success'}`);
    } catch (err) {
      log("Automation failed", a.name, "Failed");
    } finally {
      setRunningId(null);
    }
  };

  const toggle = async (a) => {
    const updated = { ...a, on: !a.on };
    setAutos(x => x.map(y => y.id === a.id ? updated : y));
    await saveAutomationToCloud(updated);
  };

  const remove = (id) => {
    setAutos(x => x.filter(y => y.id !== id));
  };

  return (
    <div className="max-w-3xl mx-auto grid gap-4">
      <div className="card p-3 flex items-center justify-between text-xs" style={{ background: "rgba(139,92,246,.1)", borderColor: "var(--pu)" }}>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: "#4ADE80" }} />
          <span>Automation Engine Ready · Backend triggers & Edge Function runners</span>
        </div>
        <span className="mu text-xs">Idempotent execution</span>
      </div>

      <form onSubmit={add} className="card p-4 flex flex-wrap gap-2">
        <input
          className="inp flex-1 min-w-[160px]"
          placeholder="Automation name (e.g. Morning Briefing)"
          value={f.name}
          onChange={e => setF({ ...f, name: e.target.value })}
        />
        <select className="inp" value={f.trigger} onChange={e => setF({ ...f, trigger: e.target.value })}>
          {["Daily", "Weekly (Mon)", "New YouTube video", "Before deadline"].map(c => <option key={c}>{c}</option>)}
        </select>
        <input className="inp" type="time" value={f.time} onChange={e => setF({ ...f, time: e.target.value })} />
        <select className="inp" value={f.action} onChange={e => setF({ ...f, action: e.target.value })}>
          {["Show daily plan", "Remind weekly tasks", "Check YouTube channels", "Summarize tomorrow"].map(c => <option key={c}>{c}</option>)}
        </select>
        <button className="btn btn-p" type="submit">Create automation</button>
      </form>

      {autos.length === 0 && <Empty t="No automations yet. Create one above." />}

      {[true, false].map(st => autos.filter(a => a.on === st).length > 0 && (
        <div key={String(st)} className="grid gap-2">
          <h3 className="mu text-sm font-bold">{st ? "Active Automations" : "Paused Automations"}</h3>
          {autos.filter(a => a.on === st).map(a => (
            <div key={a.id} className="card p-4 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <p className="font-bold text-sm">{a.name}</p>
                <p className="text-xs mu">{a.trigger} · {fmt(a.time || "07:00")} → {a.action}</p>
                <p className="text-xs mu">Last run: {a.last}</p>
              </div>
              <button
                className="btn text-xs"
                onClick={() => run(a)}
                disabled={runningId === a.id}
              >
                {runningId === a.id ? "Running…" : "Run now"}
              </button>
              <button
                className={"tog " + (a.on ? "on" : "")}
                aria-label="Toggle automation"
                onClick={() => toggle(a)}
              />
              <button
                className="mu hover:text-red-400"
                aria-label="Delete automation"
                style={{ background: "none", border: 0 }}
                onClick={() => remove(a.id)}
              >
                <Ic n="trash" />
              </button>
            </div>
          ))}
        </div>
      ))}

      <section className="card p-4">
        <h3 className="font-bold mb-2">Execution Logs</h3>
        {hist.length === 0 && <p className="mu text-sm">No runs recorded yet.</p>}
        {hist.map(h => (
          <p key={h.id} className="text-sm py-1.5 font-mono text-xs" style={{ borderTop: "1px solid var(--line)" }}>
            {h.t}
          </p>
        ))}
      </section>
    </div>
  );
}
