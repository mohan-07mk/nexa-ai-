import {useState,useEffect,useRef} from 'react';
const f=v=>{const t=Math.floor(v/10);return `${String(Math.floor(t/6000)).padStart(2,"0")}:${String(Math.floor(t/100)%60).padStart(2,"0")}.${String(t%100).padStart(2,"0")}`};
export default function Stopwatch(){
  const [ms,setMs]=useState(0);const [run,setRun]=useState(false);const [laps,setLaps]=useState([]);const t0=useRef(0);
  useEffect(()=>{if(!run)return;t0.current=performance.now()-ms;const i=setInterval(()=>setMs(performance.now()-t0.current),50);return()=>clearInterval(i)},[run]);
  return(<div className="card p-4"><p className="mu text-xs">Stopwatch</p>
    <div className="flex items-center gap-3 flex-wrap"><p className="text-3xl font-extrabold tabular-nums flex-1">{f(ms)}</p>
      <button className="btn btn-p" onClick={()=>setRun(r=>!r)}>{run?"Stop":"Start"}</button>
      <button className="btn" disabled={!run} onClick={()=>setLaps(l=>[ms,...l])}>Lap</button>
      <button className="btn" onClick={()=>{setRun(false);setMs(0);setLaps([])}}>Reset</button></div>
    {laps.map((l,i)=><p key={i} className="text-xs mu py-1">Lap {laps.length-i} · {f(l)}</p>)}</div>);
}
