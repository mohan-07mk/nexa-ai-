// ==============================================================================
// NEXA AI — GEMINI SECURE ASSISTANT EDGE FUNCTION
// Supabase Edge Function: gemini-assistant
// Handles: User authentication, 18 function tools schema, multi-action intent
//          parsing in Thanglish/Tamil/English, Asia/Kolkata timezone awareness,
//          secure communication with Google Gemini API (gemini-1.5-pro / flash)
// ==============================================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// 18 Tool definitions with strict JSON schema for Gemini Function Calling
const TOOLS_DEFINITIONS = [
  {
    name: "create_alarm",
    description: "Sets or schedules an alarm at a specific time with optional repeat days, label and sound. Ideal for 'alarm vai', 'wake me up', 'morning 6 AM alarm'.",
    parameters: {
      type: "OBJECT",
      properties: {
        time: { type: "STRING", description: "Time in 24-hour format HH:MM (e.g. 06:00, 21:30)" },
        label: { type: "STRING", description: "Descriptive label for the alarm (e.g. Wake up, Gym)" },
        days: { 
          type: "ARRAY", 
          items: { type: "INTEGER" }, 
          description: "Days of week to repeat: 0=Sun, 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat. Empty array means one-time." 
        },
        sound: { type: "STRING", description: "Alarm ringtone name: Gentle, Classic, Rise, Digital", enum: ["Gentle", "Classic", "Rise", "Digital"] },
        snooze_mins: { type: "INTEGER", description: "Snooze duration in minutes: 0, 5, 10, 15", enum: [0, 5, 10, 15] }
      },
      required: ["time"]
    }
  },
  {
    name: "create_reminder",
    description: "Creates a reminder notification at a specific date and time. Used for 'remind pannu', 'don't forget', etc.",
    parameters: {
      type: "OBJECT",
      properties: {
        title: { type: "STRING", description: "What to remind the user about" },
        date: { type: "STRING", description: "Date in YYYY-MM-DD format" },
        time: { type: "STRING", description: "Time in 24-hour format HH:MM" },
        repeat: { type: "STRING", description: "Repeat frequency", enum: ["none", "daily", "weekdays", "weekly", "monthly"] }
      },
      required: ["title", "date", "time"]
    }
  },
  {
    name: "create_task",
    description: "Adds a task or todo item with due date and priority.",
    parameters: {
      type: "OBJECT",
      properties: {
        title: { type: "STRING", description: "Title of the task" },
        date: { type: "STRING", description: "Due date in YYYY-MM-DD format" },
        time: { type: "STRING", description: "Target completion time in HH:MM" },
        priority: { type: "STRING", description: "Priority level", enum: ["High", "Medium", "Low"] },
        category: { type: "STRING", description: "Category (e.g. Work, Study, Health, Personal)" },
        repeat: { type: "STRING", description: "Recurrence", enum: ["none", "daily", "weekdays", "weekly", "monthly"] }
      },
      required: ["title", "date"]
    }
  },
  {
    name: "update_task",
    description: "Updates an existing task status or details.",
    parameters: {
      type: "OBJECT",
      properties: {
        task_id: { type: "STRING", description: "Task ID" },
        title: { type: "STRING", description: "Updated title" },
        done: { type: "BOOLEAN", description: "True if marked completed, false otherwise" },
        priority: { type: "STRING", enum: ["High", "Medium", "Low"] }
      },
      required: ["task_id"]
    }
  },
  {
    name: "delete_task",
    description: "Deletes a task by ID or title match.",
    parameters: {
      type: "OBJECT",
      properties: {
        task_id: { type: "STRING", description: "Unique task ID or title to match" }
      },
      required: ["task_id"]
    }
  },
  {
    name: "create_calendar_event",
    description: "Creates an event in the user's calendar and prepares sync with Google Calendar.",
    parameters: {
      type: "OBJECT",
      properties: {
        title: { type: "STRING", description: "Event title (e.g. Project meeting, Doctor appointment)" },
        date: { type: "STRING", description: "Date in YYYY-MM-DD format" },
        time: { type: "STRING", description: "Start time in HH:MM" },
        end_time: { type: "STRING", description: "End time in HH:MM" },
        category: { type: "STRING", enum: ["Work", "Personal", "Health", "Study"] },
        description: { type: "STRING", description: "Event description or location" }
      },
      required: ["title", "date", "time"]
    }
  },
  {
    name: "search_youtube_videos",
    description: "Searches YouTube videos from the user's monitored channels or general query.",
    parameters: {
      type: "OBJECT",
      properties: {
        query: { type: "STRING", description: "Search keyword" },
        channel_name: { type: "STRING", description: "Optional channel filter" }
      },
      required: ["query"]
    }
  },
  {
    name: "get_latest_channel_videos",
    description: "Retrieves the newest videos fetched from user's monitored channels.",
    parameters: {
      type: "OBJECT",
      properties: {
        limit: { type: "INTEGER", description: "Max videos to return (default 5)" }
      }
    }
  },
  {
    name: "create_recurring_schedule",
    description: "Creates a repeating schedule or reminder (e.g. Every Monday 8 AM weekly planning).",
    parameters: {
      type: "OBJECT",
      properties: {
        title: { type: "STRING", description: "What the recurring schedule is for" },
        date: { type: "STRING", description: "Starting date in YYYY-MM-DD" },
        time: { type: "STRING", description: "Time in HH:MM" },
        repeat: { type: "STRING", enum: ["daily", "weekdays", "weekly", "monthly"] }
      },
      required: ["title", "time", "repeat"]
    }
  },
  {
    name: "create_automation",
    description: "Creates a background automation routine (e.g. Every morning 7 AM give today's schedule).",
    parameters: {
      type: "OBJECT",
      properties: {
        name: { type: "STRING", description: "Automation name" },
        trigger_type: { type: "STRING", enum: ["Daily", "Weekly (Mon)", "New YouTube video", "Before deadline"] },
        trigger_time: { type: "STRING", description: "Time of day in HH:MM" },
        action_type: { type: "STRING", enum: ["Show daily plan", "Remind weekly tasks", "Check YouTube channels", "Summarize tomorrow"] }
      },
      required: ["name", "trigger_type", "action_type"]
    }
  },
  {
    name: "update_automation",
    description: "Toggles or updates an existing automation.",
    parameters: {
      type: "OBJECT",
      properties: {
        automation_id: { type: "STRING", description: "ID of automation" },
        is_active: { type: "BOOLEAN", description: "Active status" }
      },
      required: ["automation_id", "is_active"]
    }
  },
  {
    name: "save_memory",
    description: "Saves a personal fact, preference, or important note about the user to long-term memory.",
    parameters: {
      type: "OBJECT",
      properties: {
        title: { type: "STRING", description: "Brief memory title" },
        body: { type: "STRING", description: "Full detail of the memory or preference" },
        category: { type: "STRING", enum: ["Preference", "Memory", "Important", "Note"] }
      },
      required: ["title", "body"]
    }
  },
  {
    name: "search_memory",
    description: "Searches the user's stored memories and preferences.",
    parameters: {
      type: "OBJECT",
      properties: {
        query: { type: "STRING", description: "Search query" }
      },
      required: ["query"]
    }
  },
  {
    name: "create_note",
    description: "Creates a quick note in the user's notebook.",
    parameters: {
      type: "OBJECT",
      properties: {
        title: { type: "STRING", description: "Note title" },
        body: { type: "STRING", description: "Note content" },
        category: { type: "STRING", description: "Category tag" }
      },
      required: ["title", "body"]
    }
  },
  {
    name: "search_web",
    description: "Searches the web for up-to-date information, weather, or facts.",
    parameters: {
      type: "OBJECT",
      properties: {
        query: { type: "STRING", description: "Web search query" }
      },
      required: ["query"]
    }
  },
  {
    name: "get_daily_schedule",
    description: "Retrieves all tasks, alarms, and events for a given day (defaults to today).",
    parameters: {
      type: "OBJECT",
      properties: {
        date: { type: "STRING", description: "Date in YYYY-MM-DD format" }
      }
    }
  },
  {
    name: "get_upcoming_reminders",
    description: "Fetches upcoming active reminders.",
    parameters: {
      type: "OBJECT",
      properties: {
        days_ahead: { type: "INTEGER", description: "Number of days ahead to inspect (default 7)" }
      }
    }
  },
  {
    name: "get_productivity_summary",
    description: "Generates a productivity summary of tasks completed, open tasks, and upcoming milestones.",
    parameters: {
      type: "OBJECT",
      properties: {}
    }
  }
];

// Helper to construct the system prompt
function buildSystemPrompt(userProfile: any, contextData: any) {
  const now = new Date();
  const istOffset = 5.5 * 60 * 60 * 1000;
  const istDate = new Date(now.getTime() + istOffset);
  const todayStr = istDate.toISOString().split("T")[0];
  const timeStr = istDate.toISOString().split("T")[1].slice(0, 5);

  return `You are NEXA AI, an advanced, highly capable personal AI agent and assistant.
You communicate naturally with the user in Thanglish (Tamil written in English script), Tamil, or English, matching the user's chosen tone and language.

CURRENT TIME CONTEXT:
- Current Date (Asia/Kolkata): ${todayStr}
- Current Time (Asia/Kolkata): ${timeStr}
- User Timezone: Asia/Kolkata (IST, UTC+05:30)
- User Name: ${userProfile?.display_name || "User"}
- Preferred Language: ${userProfile?.language_pref || "Thanglish"}

THICK THANGLISH & TAMIL UNDERSTANDING RULES:
1. Understand colloquial Tamil/Thanglish terms seamlessly:
   - "Naalaiku" = Tomorrow
   - "Innaiku" = Today
   - "Mani" = O'clock / Time (e.g., "6 mani" = 6:00, "9 mani" = 9:00)
   - "Kaalaila" / "Morning" = AM
   - "Sayangalam" / "Evening" / "Night" = PM
   - "Alarm vai" / "Alarm podu" = set alarm -> tool 'create_alarm'
   - "Remind pannu" / "Ninaivupaduthu" = set reminder -> tool 'create_reminder'
   - "Task podu" / "Todo create pannu" = add task -> tool 'create_task'
   - "Schedule pannu" = add calendar event / schedule -> tool 'create_calendar_event'
   - "Pudhu video" = latest video -> tool 'get_latest_channel_videos' / 'search_youtube_videos'
   - "Enna schedule irukku?" = what is scheduled? -> tool 'get_daily_schedule'
   - "Ninaivu vechuko" = remember this -> tool 'save_memory'
2. MULTI-ACTION HANDLING:
   If the user asks for multiple actions in one sentence (e.g. "Naalaiku 6 AM alarm vai, 9 AM assignment remind pannu, evening 7 PM project work schedule pannu"), you MUST call ALL corresponding tools in parallel.
3. CONVERSATIONAL TONE:
   Keep your natural language responses warm, respectful, concise, and helpful. Use friendly Thanglish like "Seri!", "Kandippa!", "Done!", "Nan ready!".
4. TIME AND DATE PRECISION:
   Always calculate exact dates. If today is ${todayStr}, "naalaiku" is the next day. If time is "6 mani" and "morning" is mentioned, time is "06:00". If "night 9 mani", time is "21:00".`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
    const geminiApiKey = Deno.env.get("GEMINI_API_KEY") ?? "";

    const authHeader = req.headers.get("Authorization");
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader || "" } },
    });

    const body = await req.json();
    const { message, conversation_id, history = [], user_context = {} } = body;

    if (!message || typeof message !== "string") {
      return new Response(JSON.stringify({ error: "Missing 'message' string in request body" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fallback if GEMINI_API_KEY is not set yet in Supabase secrets
    if (!geminiApiKey) {
      // Local robust parser fallback inside the Edge Function
      const mockResult = parseMessageLocally(message);
      return new Response(JSON.stringify({
        source: "edge-function-local-engine",
        reply: mockResult.reply,
        actions: mockResult.actions,
        warning: "GEMINI_API_KEY secret is not yet set in Supabase Edge Function secrets. Used built-in Thanglish parser."
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Call Gemini with Function Calling enabled
    const systemPrompt = buildSystemPrompt(user_context.profile, user_context);
    
    // Format Gemini Request Payload
    const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiApiKey}`;

    // Convert history to Gemini format
    const contents: any[] = [];

    // Add prior conversation messages
    for (const h of history.slice(-6)) {
      if (h.role === "user" || h.role === "assistant") {
        contents.push({
          role: h.role === "assistant" ? "model" : "user",
          parts: [{ text: h.text || h.content || "" }]
        });
      }
    }

    // Add current user message
    contents.push({
      role: "user",
      parts: [{ text: message }]
    });

    const geminiPayload = {
      systemInstruction: {
        parts: [{ text: systemPrompt }]
      },
      contents: contents,
      tools: [{
        functionDeclarations: TOOLS_DEFINITIONS
      }],
      toolConfig: {
        functionCallingConfig: {
          mode: "AUTO"
        }
      },
      generationConfig: {
        temperature: 0.3,
        maxOutputTokens: 1024
      }
    };

    const geminiRes = await fetch(geminiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(geminiPayload)
    });

    if (!geminiRes.ok) {
      const errText = await geminiRes.text();
      console.error("Gemini API Error:", geminiRes.status, errText);
      // Fallback gracefully to local parser
      const mockResult = parseMessageLocally(message);
      return new Response(JSON.stringify({
        source: "edge-fallback",
        reply: mockResult.reply,
        actions: mockResult.actions,
        error: `Gemini API returned status ${geminiRes.status}. Fallback executed.`
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    const geminiData = await geminiRes.json();
    const candidate = geminiData.candidates?.[0];
    const parts = candidate?.content?.parts || [];

    const actions: any[] = [];
    let textReply = "";

    for (const part of parts) {
      if (part.text) {
        textReply += part.text + " ";
      }
      if (part.functionCall) {
        actions.push({
          id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          type: part.functionCall.name,
          args: part.functionCall.args,
          status: "pending"
        });
      }
    }

    if (!textReply.trim() && actions.length > 0) {
      if (actions.length === 1) {
        textReply = `Seri! I've prepared this action for you: **${actions[0].type.replace(/_/g, " ")}**. Confirm pannalama?`;
      } else {
        textReply = `Seri! I've prepared ${actions.length} actions based on your request. Check pannitu confirm pannunga!`;
      }
    }

    return new Response(JSON.stringify({
      source: "gemini-1.5",
      reply: textReply.trim(),
      actions: actions
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error: any) {
    console.error("Handler error:", error);
    return new Response(JSON.stringify({ error: error.message || "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

// Fallback robust local parser for offline / pre-key mode
function parseMessageLocally(text: string) {
  const t = text.toLowerCase();
  const actions: any[] = [];
  
  const now = new Date();
  const istOffset = 5.5 * 60 * 60 * 1000;
  const istDate = new Date(now.getTime() + istOffset);
  const todayStr = istDate.toISOString().split("T")[0];
  const tomorrow = new Date(istDate.getTime() + 86400000);
  const tomorrowStr = tomorrow.toISOString().split("T")[0];

  // Helper date extractor
  const hasTomorrow = /naalaiku|tomorrow|நாளை|நாளைக்கு/.test(t);
  const targetDate = hasTomorrow ? tomorrowStr : todayStr;

  // Split multiple clauses if present: e.g. "6 AM alarm vai, 9 AM assignment remind pannu"
  const clauses = text.split(/,|\band\b|\baprom\b|\bappuram\b|\bpinpu\b|மற்றும்|பிறகு/i);

  for (const clause of clauses) {
    const ct = clause.toLowerCase().trim();
    if (!ct) continue;

    const m = ct.match(/(\d{1,2})(?::(\d{2}))?\s*(mani|am|pm|மணி|மணிக்கு)?/i);
    let h = m ? +m[1] : null;
    const min = m && m[2] ? +m[2] : 0;
    const isPm = /evening|night|pm|raat|sayangalam|மாலை|இரவு/.test(ct);
    if (h !== null) {
      if (isPm && h < 12) h += 12;
      if (!isPm && h === 12) h = 0;
    }
    const time = h !== null ? `${String(h).padStart(2, "0")}:${String(min).padStart(2, "0")}` : "09:00";
    const titleClean = clause.replace(/\b(naalaiku|innaiku|tomorrow|today|morning|evening|night|remind(er)?|pannu|panni|vai|set|add|create|task|me|to|every|daily|weekly|please|remember|that|search|google|schedule)\b|\d{1,2}(:\d{2})?\s*(mani|am|pm|மணி|மணிக்கு)?/gi, "")
      .replace(/நாளை|நாளைக்கு|இன்று|காலை|மாலை|இரவு|அலாரம்|வை|ஞாபகப்படுத்து|நினைவூட்டு|திட்டம்|போடு/g, "")
      .replace(/\s+/g, " ")
      .trim() || "Untitled";

    if (/alarm|அலாரம்/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "create_alarm",
        args: { time, label: titleClean === "Untitled" ? "Alarm" : titleClean, days: [] },
        status: "pending"
      });
    } else if (/\b(every|daily|weekly|ஒவ்வொரு|தினமும்)\b/.test(ct) && /remind|schedule|ஞாபகப்படுத்து/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "create_recurring_schedule",
        args: {
          title: titleClean,
          date: targetDate,
          time,
          repeat: /weekday/.test(ct) ? "weekdays" : /week|monday|tuesday|wednesday|thursday|friday|saturday|sunday|திங்கள்/.test(ct) ? "weekly" : "daily"
        },
        status: "pending"
      });
    } else if (/remind|reminder|ninaivupaduthu|ஞாபகப்படுத்து|நினைவூட்டு/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "create_reminder",
        args: { title: titleClean, date: targetDate, time },
        status: "pending"
      });
    } else if (/\btask\b|todo|vela|வேலை|பணி/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "create_task",
        args: { title: titleClean, date: targetDate, time, priority: "Medium" },
        status: "pending"
      });
    } else if (/meeting|event|appointment|schedule|சந்திப்பு|திட்டம்/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "create_calendar_event",
        args: { title: titleClean, date: targetDate, time, category: "Work" },
        status: "pending"
      });
    } else if (/remember|ninaivu|save memory|gnyabagam|ஞாபகம்|நினைவு/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "save_memory",
        args: { title: titleClean, body: clause.trim(), category: "Memory" },
        status: "pending"
      });
    } else if (/youtube|video|காணொளி|வீடியோ/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "get_latest_channel_videos",
        args: { limit: 5 },
        status: "pending"
      });
    }
  }

  let reply = "";
  if (actions.length === 0) {
    reply = "I'm NEXA AI. Try asking: **Naalaiku morning 6 mani alarm vai**, **Innaiku night 9 mani project work remind pannu**, or **Tomorrow enna schedule irukku?**";
  } else if (actions.length === 1) {
    reply = `Seri! I've prepared this action for you: **${actions[0].type.replace(/_/g, " ")}**. Confirm pannalama?`;
  } else {
    reply = `Seri! I've recognized ${actions.length} actions from your message. Review pannitu confirm pannunga!`;
  }

  return { reply, actions };
}

