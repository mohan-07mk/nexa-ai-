import {today,addDays} from '../utils/helpers';
export const SEED_TASKS=[
 {id:1,title:"Submit assignment",date:today(),time:"19:00",pri:"High",cat:"Study",done:false},
 {id:2,title:"Workout – leg day",date:today(),time:"06:30",pri:"Medium",cat:"Health",done:true},
 {id:3,title:"Review project plan",date:addDays(1),time:"10:00",pri:"Medium",cat:"Work",done:false},
 {id:4,title:"Pay electricity bill",date:addDays(-1),time:"18:00",pri:"High",cat:"Personal",done:false}];
export const SEED_ALARMS=[
 {id:1,time:"06:00",label:"Wake up",days:[1,2,3,4,5],on:true},
 {id:2,time:"08:00",label:"Weekly workout",days:[1],on:true},
 {id:3,time:"22:30",label:"Sleep reminder",days:[0,1,2,3,4,5,6],on:false}];
export const SEED_ACT=[
 {id:1,name:"Task completed",desc:"Workout – leg day",status:"Success",at:"Today, 7:12 AM"},
 {id:2,name:"Alarm configured",desc:"Wake up · 6:00 AM (demo)",status:"Success",at:"Yesterday, 9:40 PM"},
 {id:3,name:"YouTube check",desc:"Not connected yet — connect in a later stage",status:"Failed",at:"Yesterday, 8:05 PM"}];
export const SEED_YT=[
 {id:1,name:"demo-tech-weekly",url:"youtube.com/@demo-tech-weekly",notify:true,video:{title:"[Demo] Weekly gadget roundup",date:addDays(0),isNew:true}},
 {id:2,name:"demo-tamil-cooking",url:"youtube.com/@demo-tamil-cooking",notify:true,video:{title:"[Demo] Sunday kuzhambu recipe",date:addDays(-2),isNew:false}},
 {id:3,name:"demo-study-tips",url:"youtube.com/@demo-study-tips",notify:false,video:{title:"[Demo] Exam planning in 10 minutes",date:addDays(-5),isNew:false}}];
export const SEED_EV=[{id:1,title:"Team sync",date:today(),time:"15:00",cat:"Work"},{id:2,title:"Doctor appointment",date:addDays(2),time:"11:30",cat:"Health"}];
export const SEED_AUTO=[{id:1,name:"Morning daily plan",trigger:"Daily",time:"07:00",action:"Show daily plan",on:true,last:"Never"},{id:2,name:"Monday weekly tasks",trigger:"Weekly (Mon)",time:"08:00",action:"Remind weekly tasks",on:false,last:"Never"}];
export const SEED_NOTES=[{id:1,title:"Prefers Thanglish replies",body:"Short, friendly answers.",cat:"Preference"},{id:2,title:"Exam on the 20th",body:"Revise chapters 4 to 7.",cat:"Important"}];
export const SEED_SET={name:"Demo User",email:"demo@example.com",lang:"Thanglish",model:"Gemini (placeholder)",memory:true,nReminders:true,nYt:true,nDaily:false,nAuto:true};
