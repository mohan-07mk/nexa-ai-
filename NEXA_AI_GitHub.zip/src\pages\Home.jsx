import React, { useState } from 'react';
import { Ic } from '../components/Icon';
import { today, fmt } from '../utils/helpers';
import { startVoiceRecognition, stopVoiceRecognition, isSTTSupported, speakText, isTTSSupported } from '../services/voiceService';

export default function Home({ tasks = [], alarms = [], act = [], yt = [], ev = [], autos = [], go, setDraft, set }) {
  const h = new Date().getHours();
  const greet = h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";

  const todaysTasks = tasks.filter(t => t.date === today());
  const openTasks = todaysTasks.filter(t => !t.done);
  const nextAlarm = alarms.filter(a => a.on).sort((a, b) => a.time.localeCompare(b.time))[0];
  const upcomingEvents = ev.filter(e => e.date >= today()).slice(0, 3);
  const newVideos = yt.filter(c => c.video && c.video.isNew);
  const activeAutos = autos.filter(a => a.on);

  const [q, setQ] = useState("");
  const [isListening, setIsListening] = useState(false);

  // Generate dynamic AI briefing from real user data
  const userName = set?.name ? set.name.split(" ")[0] : "there";
  const briefingText = `${greet} ${userName}! Innaiku unakku ${openTasks.length} open tasks, ${upcomingEvents.length} meetings, and ${nextAlarm ? `next alarm at ${fmt(nextAlarm.time)}` : "no alarms"} irukku.`;

  const ask = (e) => {
    e.preventDefault();
    if (!q.trim()) return;
    setDraft(q);
    go("assistant");
  };

  const handleVoiceInput = () => {
    if (isListening) {
      stopVoiceRecognition();
      setIsListening(false);
    } else {
      const rec = startVoiceRecognition({
        lang: set?.lang === "Tamil" ? "ta-IN" : "en-IN",
        onResult: ({ transcript, isFinal }) => {
          setQ(transcript);
          if (isFinal) {
            setIsListening(false);
            setDraft(transcript);
            go("assistant");
          }
        },
        onError: () => setIsListening(false),
        onEnd: () => setIsListening(false)
      });
      if (rec) setIsListening(true);
    }
  };

  return (
    <div className="max-w-5xl mx-auto grid gap-4">
      {/* Hero card with AI briefing */}
      <section className="card p-5 md:p-7 relative overflow-hidden" style={{ background: "linear-gradient(160deg,#1c1538,var(--card) 65%)" }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: "var(--cy)" }} />
            <span className="text-xs font-bold uppercase tracking-wider" style={{ color: "var(--cy)" }}>
              Daily AI Intelligence
            </span>
          </div>
          {isTTSSupported() && (
            <button
              className="btn text-xs py-1 px-2.5 flex items-center gap-1.5"
              onClick={() => speakText(briefingText, { lang: set?.lang === "Tamil" ? "ta-IN" : "en-IN" })}
            >
              <Ic n="vol" s={14} /> Listen
            </button>
          )}
        </div>

        <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight mt-2">
          {greet}, {userName}.
        </h2>
        <p className="mu mt-1 text-sm md:text-base leading-relaxed">
          {briefingText}
        </p>

        <form onSubmit={ask} className="flex gap-2 mt-4 items-center">
          <button
            type="button"
            className="btn"
            style={isListening ? { background: "#EF4444", borderColor: "#EF4444", color: "#fff" } : {}}
            title="Voice input (Thanglish/Tamil)"
            onClick={handleVoiceInput}
          >
            <Ic n={isListening ? "stop" : "mic"} s={18} />
          </button>
          <input
            className="inp flex-1"
            value={q}
            onChange={e => setQ(e.target.value)}
            placeholder={isListening ? "Listening in Thanglish/Tamil…" : "Naalaiku morning 6 mani alarm vai"}
          />
          <button className="btn btn-p" type="submit">Ask AI</button>
        </form>

        <div className="flex flex-wrap gap-2 mt-3">
          {[
            ["Set alarm", "alarms"],
            ["Add task", "tasks"],
            ["Calendar", "calendar"],
            ["YouTube Monitor", "youtube"],
            ["Automations", "automations"]
          ].map(([l, p]) => (
            <button key={l} className="btn text-xs" onClick={() => go(p)}>{l}</button>
          ))}
        </div>
      </section>

      {/* Quick stats grid */}
      <div className="grid sm:grid-cols-4 gap-4">
        <button className="card p-4 text-left hover:border-[var(--pu)] transition-all" onClick={() => go("tasks")}>
          <p className="mu text-xs">Today's tasks</p>
          <p className="text-3xl font-extrabold mt-1">
            {openTasks.length}
            <span className="mu text-base font-semibold"> of {todaysTasks.length}</span>
          </p>
        </button>

        <button className="card p-4 text-left hover:border-[var(--pu)] transition-all" onClick={() => go("alarms")}>
          <p className="mu text-xs">Next alarm</p>
          <p className="text-3xl font-extrabold mt-1">{nextAlarm ? fmt(nextAlarm.time) : "Off"}</p>
          <p className="mu text-xs truncate">{nextAlarm ? nextAlarm.label : "All alarms off"}</p>
        </button>

        <button className="card p-4 text-left hover:border-[var(--pu)] transition-all" onClick={() => go("youtube")}>
          <p className="mu text-xs">YouTube Feed</p>
          <p className="text-3xl font-extrabold mt-1">{newVideos.length}</p>
          <p className="mu text-xs">new video alerts</p>
        </button>

        <button className="card p-4 text-left hover:border-[var(--pu)] transition-all" onClick={() => go("automations")}>
          <p className="mu text-xs">Automations</p>
          <p className="text-3xl font-extrabold mt-1">{activeAutos.length}</p>
          <p className="mu text-xs">routines active</p>
        </button>
      </div>

      {/* Detail cards */}
      <div className="grid md:grid-cols-2 gap-4">
        {/* Today's Tasks */}
        <section className="card p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold">Today's Tasks</h3>
            <button className="mu text-xs hover:text-white" onClick={() => go("tasks")}>View all →</button>
          </div>
          {todaysTasks.length === 0 && (
            <p className="mu text-sm py-4 text-center">Nothing due today. Enjoy your day or add a task!</p>
          )}
          {todaysTasks.map(t => (
            <p
              key={t.id}
              className="text-sm py-2 flex justify-between items-center"
              style={{ borderTop: "1px solid var(--line)", opacity: t.done ? 0.5 : 1 }}
            >
              <span style={{ textDecoration: t.done ? "line-through" : "none" }}>{t.title}</span>
              <span className="mu text-xs font-mono">{fmt(t.time || "09:00")}</span>
            </p>
          ))}
        </section>

        {/* Upcoming Calendar Events */}
        <section className="card p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold">Upcoming Schedule</h3>
            <button className="mu text-xs hover:text-white" onClick={() => go("calendar")}>Calendar →</button>
          </div>
          {upcomingEvents.length === 0 && (
            <p className="mu text-sm py-4 text-center">No upcoming events scheduled.</p>
          )}
          {upcomingEvents.map(e => (
            <div
              key={e.id}
              className="text-sm py-2 flex justify-between items-center"
              style={{ borderTop: "1px solid var(--line)" }}
            >
              <span className="font-medium truncate">{e.title}</span>
              <span className="mu text-xs shrink-0">{e.date} · {fmt(e.time || "10:00")}</span>
            </div>
          ))}
        </section>
      </div>
    </div>
  );
}
