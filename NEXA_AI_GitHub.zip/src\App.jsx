import {Routes,Route,Navigate} from 'react-router-dom';
import MainLayout from './layouts/MainLayout';
import {useApp} from './context/AppContext';
import Home from './pages/Home';import Assistant from './pages/Assistant';import Tasks from './pages/Tasks';import Alarms from './pages/Alarms';
import Calendar from './pages/Calendar';import YouTube from './pages/YouTube';import Automations from './pages/Automations';import Memory from './pages/Memory';
import Activity from './pages/Activity';import Settings from './pages/Settings';
const Page=({C})=>{const c=useApp();return <C {...c}/>};
const R=[["home",Home],["assistant",Assistant],["tasks",Tasks],["alarms",Alarms],["calendar",Calendar],["youtube",YouTube],["automations",Automations],["memory",Memory],["activity",Activity],["settings",Settings]];
export default function App(){
  return(<Routes><Route element={<MainLayout/>}>
    <Route index element={<Navigate to="/home" replace/>}/>
    {R.map(([p,C])=><Route key={p} path={p} element={<Page C={C}/>}/>)}
    <Route path="*" element={<Navigate to="/home" replace/>}/></Route></Routes>);
}
