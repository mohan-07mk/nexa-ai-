import React from 'react';
import ReactDOM from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import App from './App';
import { AppProvider } from './context/AppContext';
import './index.css';

// Global error protection against WebView crashes
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    console.warn('Unhandled promise rejection captured & suppressed:', event.reason);
    event.preventDefault();
  });

  window.addEventListener('error', (event) => {
    console.warn('Unhandled script error captured & suppressed:', event.error || event.message);
  });
}

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('React error boundary caught error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: 20, color: '#fff', background: '#08090D', height: '100vh', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', textAlign: 'center' }}>
          <h2 style={{ fontSize: 20, marginBottom: 8, color: '#F87171' }}>NEXA AI Self-Healed</h2>
          <p style={{ fontSize: 13, color: '#9CA3AF', maxWidth: 320, marginBottom: 16 }}>
            A temporary component error occurred. Click reload to continue.
          </p>
          <button
            onClick={() => { this.setState({ hasError: false }); window.location.hash = '#/home'; }}
            style={{ padding: '8px 18px', background: '#8B5CF6', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer' }}
          >
            Reload NEXA AI
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ErrorBoundary>
      <HashRouter>
        <AppProvider>
          <App />
        </AppProvider>
      </HashRouter>
    </ErrorBoundary>
  </React.StrictMode>
);
