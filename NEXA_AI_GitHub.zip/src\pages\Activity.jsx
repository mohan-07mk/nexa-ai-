import React from 'react';
import useStore from '../hooks/useStore';

export default function Activity({act}){
  const c={Success:"#4ADE80",Pending:"#FBBF24",Failed:"#F87171","Requires confirmation":"#22D3EE"};
  return(<div className="max-w-3xl mx-auto grid gap-2">
    {act.map(a=><div key={a.id} className="card p-4 flex items-start gap-3">
      <span className="w-2.5 h-2.5 rounded-full mt-1.5 shrink-0" style={{background:c[a.status]}}/>
      <div className="flex-1 min-w-0"><p className="font-semibold text-sm">{a.name}</p><p className="text-xs mu" style={{overflowWrap:"anywhere"}}>{a.desc}</p></div>
      <div className="text-right text-xs shrink-0"><p style={{color:c[a.status]}}>{a.status}</p><p className="mu">{a.at}</p></div>
    </div>)}
  </div>);
}
