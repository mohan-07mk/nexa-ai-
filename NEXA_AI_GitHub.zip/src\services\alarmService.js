// ==============================================================================
// NEXA AI — REAL ALARM SYSTEM
// Supports: Exact alarms via Capacitor LocalNotifications, multi-alarms,
//           custom repeat days, snooze, dismiss, sound playback, Android channel
//           high-importance heads-up display, web audio fallback, and Supabase sync.
// ==============================================================================

import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { supabase, isSupabaseConfigured } from './supabaseClient.js';
import { DN, fmt } from '../utils/helpers.js';

export const isNative = () => Capacitor.isNativePlatform();

// Web Audio synthesizer for alarms when tested in a web browser
let webAudioCtx = null;
let activeAlarmOscillator = null;

export function playWebAlarmSound() {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    if (!webAudioCtx) webAudioCtx = new AudioContext();
    if (webAudioCtx.state === 'suspended') webAudioCtx.resume();

    const osc = webAudioCtx.createOscillator();
    const gain = webAudioCtx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(880, webAudioCtx.currentTime); // A5
    osc.frequency.setValueAtTime(440, webAudioCtx.currentTime + 0.3); // A4
    osc.frequency.setValueAtTime(880, webAudioCtx.currentTime + 0.6);

    gain.gain.setValueAtTime(0.3, webAudioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, webAudioCtx.currentTime + 1.2);

    osc.connect(gain);
    gain.connect(webAudioCtx.destination);
    osc.start();
    osc.stop(webAudioCtx.currentTime + 1.2);
  } catch (e) {
    console.warn('Web audio playback failed:', e);
  }
}

// Calculate the next Date for an alarm based on time and repeat days
export function getNextAlarmDate(timeStr, days = []) {
  const [h, m] = timeStr.split(':').map(Number);
  const now = new Date();
  const target = new Date();
  target.setHours(h, m, 0, 0);

  // If no repeat days, either today if in future, or tomorrow
  if (!days || days.length === 0) {
    if (target.getTime() <= now.getTime()) {
      target.setDate(target.getDate() + 1);
    }
    return target;
  }

  // If repeat days are specified: 0=Sun, 1=Mon, ..., 6=Sat
  const currentDay = now.getDay();
  // Check if target is today and still in the future and today is in repeat list
  if (days.includes(currentDay) && target.getTime() > now.getTime()) {
    return target;
  }

  // Find next matching day in the next 7 days
  for (let i = 1; i <= 7; i++) {
    const nextDay = (currentDay + i) % 7;
    if (days.includes(nextDay)) {
      target.setDate(now.getDate() + i);
      return target;
    }
  }

  return target;
}

// Convert alarm object ID to a safe 32-bit positive integer for Android notification ID
export function getNotificationId(alarmId) {
  if (typeof alarmId === 'number') {
    return Math.abs(alarmId % 2147483647) || 10001;
  }
  let hash = 0;
  const str = String(alarmId);
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash % 2147483647) || 10001;
}

// Schedule an exact native alarm
export async function scheduleNativeAlarm(alarm) {
  if (!alarm.on) {
    await cancelNativeAlarm(alarm.id);
    return;
  }

  const nextDate = getNextAlarmDate(alarm.time, alarm.days);
  const notifId = getNotificationId(alarm.id);

  if (isNative()) {
    try {
      // Cancel previous schedule for this alarm ID
      await LocalNotifications.cancel({ notifications: [{ id: notifId }] });

      // Schedule exact notification
      await LocalNotifications.schedule({
        notifications: [
          {
            id: notifId,
            title: `⏰ Alarm: ${alarm.label || 'Wake up'}`,
            body: `Scheduled for ${fmt(alarm.time)} · Tap to open NEXA AI`,
            schedule: {
              at: nextDate,
              allowWhileIdle: true // Exact alarm permission on Android 12+
            },
            channelId: 'nexa-alarms',
            actionTypeId: 'ALARM_ACTIONS',
            sound: 'beep.wav',
            extra: {
              alarmId: alarm.id,
              type: 'alarm',
              snoozeMins: alarm.snooze || 5,
              time: alarm.time,
              days: alarm.days
            }
          }
        ]
      });

      console.log(`Native alarm scheduled for ${nextDate.toISOString()} with ID ${notifId}`);
    } catch (err) {
      console.warn('Failed to schedule exact native alarm, retrying with standard idle:', err);
      try {
        await LocalNotifications.schedule({
          notifications: [
            {
              id: notifId,
              title: `⏰ Alarm: ${alarm.label || 'Wake up'}`,
              body: `Scheduled for ${fmt(alarm.time)} · Tap to open NEXA AI`,
              schedule: {
                at: nextDate,
                allowWhileIdle: false
              },
              channelId: 'nexa-alarms',
              actionTypeId: 'ALARM_ACTIONS',
              sound: 'beep.wav',
              extra: {
                alarmId: alarm.id,
                type: 'alarm',
                snoozeMins: alarm.snooze || 5,
                time: alarm.time,
                days: alarm.days
              }
            }
          ]
        });
      } catch (retryErr) {
        console.warn('Non-exact alarm fallback also failed:', retryErr);
      }
    }
  } else {
    // Web fallback: calculate timeout if within 24 hours
    const msUntil = nextDate.getTime() - Date.now();
    if (msUntil > 0 && msUntil < 86400000) {
      setTimeout(() => {
        playWebAlarmSound();
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification(`⏰ Alarm: ${alarm.label || 'Wake up'}`, {
            body: `Alarm ringing for ${fmt(alarm.time)}`,
            icon: '/favicon.ico'
          });
        }
      }, msUntil);
    }
  }
}

// Cancel a scheduled alarm
export async function cancelNativeAlarm(alarmId) {
  const notifId = getNotificationId(alarmId);
  if (isNative()) {
    try {
      await LocalNotifications.cancel({ notifications: [{ id: notifId }] });
    } catch (err) {
      console.warn('Error cancelling native alarm:', err);
    }
  }
}

// Snooze an alarm by X minutes
export async function snoozeAlarm(alarmId, snoozeMins = 5) {
  const snoozeDate = new Date(Date.now() + snoozeMins * 60 * 1000);
  const snoozeNotifId = getNotificationId(`snooze_${alarmId}`);

  if (isNative()) {
    try {
      await LocalNotifications.schedule({
        notifications: [
          {
            id: snoozeNotifId,
            title: `⏰ Snoozed Alarm`,
            body: `Snooze ended (+${snoozeMins} min) · Tap to dismiss`,
            schedule: { at: snoozeDate, allowWhileIdle: true },
            channelId: 'nexa-alarms',
            actionTypeId: 'ALARM_ACTIONS',
            sound: 'beep.wav',
            extra: { alarmId, type: 'alarm_snooze' }
          }
        ]
      });
    } catch (err) {
      console.error('Failed to schedule snooze:', err);
    }
  }
}

// Reschedule all active alarms (called on app startup / resume)
export async function syncAllAlarms(alarmsList) {
  for (const alarm of alarmsList) {
    if (alarm.on) {
      await scheduleNativeAlarm(alarm);
    } else {
      await cancelNativeAlarm(alarm.id);
    }
  }
}

// Cloud sync with Supabase
export async function saveAlarmToCloud(alarm) {
  if (!isSupabaseConfigured() || !supabase) return;
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase.from('alarms').upsert({
      id: typeof alarm.id === 'string' && alarm.id.includes('-') ? alarm.id : undefined,
      user_id: user.id,
      time: alarm.time,
      label: alarm.label || 'Alarm',
      days: alarm.days || [],
      sound: alarm.sound || 'Gentle',
      snooze_mins: alarm.snooze ?? 5,
      is_active: alarm.on
    });
  } catch (err) {
    console.warn('Cloud alarm sync failed:', err);
  }
}
