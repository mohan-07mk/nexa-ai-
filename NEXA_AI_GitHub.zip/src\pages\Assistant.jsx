import React, { useState, useEffect, useRef } from 'react';
import { Ic } from '../components/Icon';
import { fmt } from '../utils/helpers';
import { sendMessageToAgent, executeToolAction } from '../services/aiService';
import { startVoiceRecognition, stopVoiceRecognition, isSTTSupported, speakText, stopSpeaking, isTTSSupported } from '../services/voiceService';
import useStore from '../hooks/useStore';

const TOOL_TITLES = {
  create_alarm: "⏰ Create Native Alarm",
  create_reminder: "📌 Create Scheduled Reminder",
  create_task: "✓ Create Task",
  update_task: "✎ Update Task",
  delete_task: "🗑 Delete Task",
  create_calendar_event: "📅 Create Calendar Event",
  search_youtube_videos: "▶ Search YouTube",
  get_latest_channel_videos: "▶ Latest Channel Videos",
  create_recurring_schedule: "🔁 Recurring Reminder",
  create_automation: "⚡ Create Automation",
  update_automation: "⚡ Update Automation",
  save_memory: "🧠 Save to Memory",
  search_memory: "🔍 Search Memory",
  create_note: "📝 Create Note",
  search_web: "🌐 Search the Web",
  get_daily_schedule: "📋 Today's Schedule",
  get_upcoming_reminders: "⏰ Upcoming Reminders",
  get_productivity_summary: "📊 Productivity Summary"
};

const WELCOME = [{
  id: 0,
  role: "ai",
  text: "Vanakkam! I'm NEXA, your personal AI agent.\n\nTry asking me naturally in **Thanglish**, **Tamil**, or **English**:\n- *Naalaiku morning 6 mani alarm vai*\n- *Innaiku night 9 mani assignment remind pannu*\n- *Naalaiku 6 AM alarm vai, 9 AM assignment remind pannu, evening 7 PM gym schedule pannu*\n- *Tomorrow enna schedule irukku?*"
}];

export default function Assistant({ setAlarms, setTasks, setEv, setNotes, log, draft, setDraft, tasks, alarms, ev, set }) {
  const [convos, setConvos] = useStore("nexa.convos", [{ id: 1, title: "New chat", msgs: WELCOME }]);
  const [aid, setAid] = useStore("nexa.convoActive", 1);
  const [cq, setCq] = useState("");
  const [showH, setShowH] = useState(false);

  const cur = convos.find(c => c.id === aid) || convos[0];
  const msgs = cur.msgs;

  const setMsgs = fn => setConvos(cs => cs.map(c => {
    if (c.id !== cur.id) return c;
    const nm = typeof fn === "function" ? fn(c.msgs) : fn;
    const u = nm.find(x => x.role === "user");
    return { ...c, msgs: nm, title: u ? u.text.slice(0, 32) : "New chat" };
  }));

  const newChat = () => {
    const id = Date.now();
    setConvos(cs => [{ id, title: "New chat", msgs: WELCOME }, ...cs]);
    setAid(id);
    setShowH(false);
  };

  const delChat = id => {
    const rest = convos.filter(c => c.id !== id);
    if (rest.length === 0) {
      const n = { id: Date.now(), title: "New chat", msgs: WELCOME };
      setConvos([n]);
      setAid(n.id);
    } else {
      setConvos(rest);
      if (id === cur.id) setAid(rest[0].id);
    }
  };

  const hits = convos.filter(c => (c.title + " " + c.msgs.map(m => m.text).join(" ")).toLowerCase().includes(cq.toLowerCase()));

  const [busy, setBusy] = useState(false);
  const [text, setText] = useState(draft || "");
  const [isRecording, setIsRecording] = useState(false);
  const [speechError, setSpeechError] = useState("");
  const [speakingMsgId, setSpeakingMsgId] = useState(null);
  const end = useRef(null);

  useEffect(() => {
    if (draft) {
      setText(draft);
      setDraft("");
    }
  }, [draft]);

  useEffect(() => {
    end.current && end.current.scrollIntoView({ block: "end", behavior: "smooth" });
  }, [msgs, busy]);

  // Voice STT Toggle
  const toggleVoice = () => {
    if (isRecording) {
      stopVoiceRecognition();
      setIsRecording(false);
    } else {
      setSpeechError("");
      const recognitionLang = set?.lang === "Tamil" ? "ta-IN" : "en-IN";
      const rec = startVoiceRecognition({
        lang: recognitionLang,
        onResult: ({ transcript, isFinal }) => {
          setText(transcript);
          if (isFinal) {
            setIsRecording(false);
          }
        },
        onError: (err) => {
          setSpeechError("Microphone input error or permission denied.");
          setIsRecording(false);
        },
        onEnd: () => {
          setIsRecording(false);
        }
      });
      if (rec) setIsRecording(true);
      else setSpeechError("Voice input not supported in this environment.");
    }
  };

  // Text to speech
  const toggleTTS = (msgId, speechText) => {
    if (speakingMsgId === msgId) {
      stopSpeaking();
      setSpeakingMsgId(null);
    } else {
      stopSpeaking();
      setSpeakingMsgId(msgId);
      const voiceLang = set?.lang === "Tamil" ? "ta-IN" : "en-IN";
      speakText(speechText, {
        lang: voiceLang,
        onEnd: () => setSpeakingMsgId(null)
      });
    }
  };

  // Send message
  const send = async (v) => {
    v = (v ?? text).trim();
    if (!v || busy) return;

    setText("");
    stopSpeaking();
    setSpeakingMsgId(null);

    const userMsgId = Date.now();
    setMsgs(m => [...m, { id: userMsgId, role: "user", text: v }]);
    setBusy(true);

    try {
      const userContext = {
        profile: set,
        tasksCount: (tasks || []).length,
        alarmsCount: (alarms || []).length
      };

      const result = await sendMessageToAgent(v, msgs, userContext);

      // Support array of actions (multi-action request) or single action
      const actionsList = (result.actions || []).map(a => ({
        ...a,
        status: a.status || "pending"
      }));

      setMsgs(m => [
        ...m,
        {
          id: Date.now() + 1,
          role: "ai",
          text: result.reply,
          actions: actionsList,
          source: result.source
        }
      ]);
    } catch (err) {
      setMsgs(m => [
        ...m,
        {
          id: Date.now() + 1,
          role: "ai",
          text: `Mannikavum! An error occurred: ${err.message || "Failed to process request."}`
        }
      ]);
    } finally {
      setBusy(false);
    }
  };

  // Confirm single action
  const confirmAction = async (msgId, actionId) => {
    const msg = msgs.find(m => m.id === msgId);
    if (!msg || !msg.actions) return;

    const targetAction = msg.actions.find(a => a.id === actionId);
    if (!targetAction) return;

    try {
      const execResult = await executeToolAction(targetAction, {
        setAlarms,
        setTasks,
        setEv,
        setNotes,
        log,
        tasks,
        alarms,
        ev
      });

      setMsgs(m => m.map(x => {
        if (x.id !== msgId) return x;
        return {
          ...x,
          actions: x.actions.map(a => a.id === actionId ? { ...a, status: "confirmed", result: execResult.message } : a)
        };
      }));
    } catch (err) {
      console.error("Tool execution failed:", err);
      setMsgs(m => m.map(x => {
        if (x.id !== msgId) return x;
        return {
          ...x,
          actions: x.actions.map(a => a.id === actionId ? { ...a, status: "failed", error: err.message } : a)
        };
      }));
    }
  };

  // Confirm ALL actions in message
  const confirmAllActions = async (msgId) => {
    const msg = msgs.find(m => m.id === msgId);
    if (!msg || !msg.actions) return;

    for (const a of msg.actions) {
      if (a.status === "pending") {
        await confirmAction(msgId, a.id);
      }
    }
  };

  // Dismiss action
  const dismissAction = (msgId, actionId) => {
    setMsgs(m => m.map(x => {
      if (x.id !== msgId) return x;
      return {
        ...x,
        actions: x.actions.map(a => a.id === actionId ? { ...a, status: "dismissed" } : a)
      };
    }));
  };

  // Edit action args inline
  const updateActionArg = (msgId, actionId, field, value) => {
    setMsgs(m => m.map(x => {
      if (x.id !== msgId) return x;
      return {
        ...x,
        actions: x.actions.map(a => {
          if (a.id !== actionId) return a;
          return {
            ...a,
            args: { ...a.args, [field]: value }
          };
        })
      };
    }));
  };

  const md = s => s.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/g).map((p, i) =>
    p.startsWith("**") ? <strong key={i}>{p.slice(2, -2)}</strong> :
    p.startsWith("*") && p.length > 2 ? <em key={i}>{p.slice(1, -1)}</em> : p
  );

  return (
    <div className="max-w-3xl mx-auto flex flex-col" style={{ minHeight: "calc(100% - 0px)" }}>
      {/* Top action bar */}
      <div className="flex flex-wrap gap-2 mb-3 items-center">
        <button className="btn btn-p" onClick={newChat}>New chat</button>
        <button className="btn" onClick={() => setShowH(!showH)}>{showH ? "Hide history" : "History"}</button>
        <button className="btn" onClick={() => setMsgs(WELCOME)}>Clear chat</button>
        <span className="mu text-xs truncate ml-auto">{cur.title}</span>
      </div>

      {/* History modal drawer */}
      {showH && (
        <div className="card p-3 mb-3 grid gap-2">
          <input className="inp" placeholder="Search conversations" value={cq} onChange={e => setCq(e.target.value)} />
          {hits.length === 0 && <p className="mu text-sm">No conversations match.</p>}
          {hits.map(c => (
            <div key={c.id} className="flex items-center gap-2">
              <button
                className="btn flex-1 text-left truncate"
                style={c.id === cur.id ? { borderColor: "var(--pu)" } : {}}
                onClick={() => { setAid(c.id); setShowH(false); }}
              >
                {c.title}
              </button>
              <button className="mu text-xs" style={{ background: "none", border: 0 }} aria-label="Delete conversation" onClick={() => delChat(c.id)}>Delete</button>
            </div>
          ))}
        </div>
      )}

      {/* Messages stream */}
      <div className="flex-1 grid gap-3 content-start">
        {msgs.map(m => (
          <div key={m.id} className={"flex " + (m.role === "user" ? "justify-end" : "")}>
            <div
              className="max-w-[92%] md:max-w-[85%] px-4 py-3 text-sm"
              style={m.role === "user"
                ? { background: "var(--pu)", borderRadius: "18px 18px 4px 18px" }
                : { background: "var(--card)", border: "1px solid var(--line)", borderRadius: "18px 18px 18px 4px" }}
            >
              <p style={{ overflowWrap: "anywhere", whiteSpace: "pre-line" }}>{md(m.text)}</p>

              {/* Multi-Action Preview Cards */}
              {m.actions && m.actions.length > 0 && (
                <div className="mt-3 grid gap-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold mu">Actions ({m.actions.length})</span>
                    {m.actions.some(a => a.status === "pending") && (
                      <button
                        className="btn btn-p text-xs py-1 px-2.5 flex items-center gap-1"
                        onClick={() => confirmAllActions(m.id)}
                      >
                        <Ic n="checkall" s={14} /> Confirm All
                      </button>
                    )}
                  </div>

                  {m.actions.map(action => (
                    <div
                      key={action.id}
                      className="p-3 rounded-xl"
                      style={{ background: "var(--bg2)", border: "1px solid var(--line)" }}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs mu font-mono">{action.type}</span>
                        <span
                          className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full"
                          style={{
                            background: action.status === "confirmed" ? "rgba(74,222,128,.15)" :
                                        action.status === "failed" ? "rgba(248,113,113,.15)" :
                                        action.status === "dismissed" ? "rgba(146,152,170,.15)" :
                                        "rgba(34,211,238,.15)",
                            color: action.status === "confirmed" ? "#4ADE80" :
                                   action.status === "failed" ? "#F87171" :
                                   action.status === "dismissed" ? "var(--mu)" :
                                   "var(--cy)"
                          }}
                        >
                          {action.status}
                        </span>
                      </div>

                      <p className="font-bold text-sm mt-1">{TOOL_TITLES[action.type] || action.type}</p>

                      {/* Editable parameters for pending actions */}
                      {action.status === "pending" && action.args && (
                        <div className="flex gap-2 mt-2 flex-wrap text-xs">
                          {"title" in action.args && (
                            <input
                              className="inp text-xs flex-1 min-w-[120px]"
                              value={action.args.title}
                              onChange={e => updateActionArg(m.id, action.id, "title", e.target.value)}
                              placeholder="Title"
                            />
                          )}
                          {"label" in action.args && (
                            <input
                              className="inp text-xs flex-1 min-w-[120px]"
                              value={action.args.label}
                              onChange={e => updateActionArg(m.id, action.id, "label", e.target.value)}
                              placeholder="Label"
                            />
                          )}
                          {"date" in action.args && (
                            <input
                              type="date"
                              aria-label="Date"
                              className="inp text-xs"
                              value={action.args.date}
                              onChange={e => updateActionArg(m.id, action.id, "date", e.target.value)}
                            />
                          )}
                          {"time" in action.args && (
                            <input
                              type="time"
                              aria-label="Time"
                              className="inp text-xs"
                              value={action.args.time}
                              onChange={e => updateActionArg(m.id, action.id, "time", e.target.value)}
                            />
                          )}
                        </div>
                      )}

                      <pre className="text-[11px] mu mt-1.5 whitespace-pre-wrap font-mono">
                        {JSON.stringify(action.args, null, 2)}
                      </pre>

                      {action.status === "pending" && (
                        <div className="flex gap-2 mt-3">
                          <button
                            className="btn btn-p text-xs py-1 px-3"
                            onClick={() => confirmAction(m.id, action.id)}
                          >
                            Confirm
                          </button>
                          <button
                            className="btn text-xs py-1 px-3"
                            onClick={() => dismissAction(m.id, action.id)}
                          >
                            Dismiss
                          </button>
                        </div>
                      )}

                      {action.status === "confirmed" && (
                        <p className="text-xs mt-2" style={{ color: "#4ADE80" }}>
                          ✓ {action.result || "Executed and scheduled on Android system."}
                        </p>
                      )}

                      {action.status === "failed" && (
                        <p className="text-xs mt-2" style={{ color: "#F87171" }}>
                          ✕ Failed: {action.error}
                        </p>
                      )}

                      {action.status === "dismissed" && (
                        <p className="text-xs mt-2 mu">Action dismissed.</p>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* AI message footer actions (TTS Audio, Copy) */}
              {m.role === "ai" && (
                <div className="flex items-center gap-3 mt-2.5 pt-2" style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}>
                  {isTTSSupported() && (
                    <button
                      className="mu text-xs flex items-center gap-1 hover:text-white"
                      style={{ background: "none", border: 0 }}
                      onClick={() => toggleTTS(m.id, m.text)}
                    >
                      <Ic n={speakingMsgId === m.id ? "stop" : "vol"} s={13} />
                      {speakingMsgId === m.id ? "Stop voice" : "Listen"}
                    </button>
                  )}
                  <button
                    className="mu text-xs hover:text-white"
                    style={{ background: "none", border: 0 }}
                    onClick={() => {
                      try { navigator.clipboard.writeText(m.text); } catch (e) {}
                    }}
                  >
                    Copy
                  </button>
                  {m.source && (
                    <span className="mu text-[10px] ml-auto font-mono opacity-60">
                      via {m.source}
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}

        {busy && (
          <div className="card px-4 py-3 w-fit flex gap-1 items-center" aria-label="NEXA is typing">
            {[0, 1, 2].map(i => (
              <span key={i} className="dot w-2 h-2 rounded-full" style={{ background: "var(--cy)" }} />
            ))}
            <span className="mu text-xs ml-2">NEXA is thinking…</span>
          </div>
        )}
        <div ref={end} />
      </div>

      {/* Suggested prompts & Input dock */}
      <div className="sticky bottom-0 pt-3" style={{ background: "var(--bg)" }}>
        {speechError && (
          <p className="text-xs mb-2 p-2 rounded-lg" style={{ background: "rgba(248,113,113,0.15)", color: "#F87171" }}>
            {speechError}
          </p>
        )}

        <div className="flex gap-2 overflow-x-auto pb-2">
          {[
            "Naalaiku morning 6 mani alarm vai",
            "Innaiku night 9 mani assignment remind pannu",
            "Naalaiku 6 AM alarm vai, 9 AM assignment remind pannu",
            "Tomorrow enna schedule irukku?"
          ].map(s => (
            <button key={s} className="btn whitespace-nowrap text-xs" onClick={() => send(s)}>
              {s}
            </button>
          ))}
        </div>

        <form className="flex gap-2 items-center" onSubmit={e => { e.preventDefault(); send(); }}>
          <button
            type="button"
            className="btn"
            style={isRecording ? { background: "#EF4444", borderColor: "#EF4444", color: "#fff" } : {}}
            aria-label="Voice input"
            title={isRecording ? "Stop voice recording" : "Speak in Thanglish/Tamil"}
            onClick={toggleVoice}
          >
            <Ic n={isRecording ? "stop" : "mic"} s={18} />
          </button>

          <input
            className="inp flex-1"
            value={text}
            onChange={e => setText(e.target.value)}
            placeholder={isRecording ? "Listening to your voice in Thanglish/Tamil…" : "Message NEXA in Thanglish, Tamil, or English…"}
          />

          <button className="btn btn-p" type="submit" aria-label="Send" disabled={busy}>
            <Ic n="send" s={18} />
          </button>
        </form>
      </div>
    </div>
  );
}
