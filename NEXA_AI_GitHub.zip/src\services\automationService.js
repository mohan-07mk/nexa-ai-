// ==============================================================================
// NEXA AI — AUTOMATION SERVICE
// Coordinates automation definitions, backend cron execution triggers,
// execution tracking, and status synchronization.
// ==============================================================================

import { supabase, isSupabaseConfigured } from './supabaseClient.js';

export async function runAutomationNow(automation) {
  if (isSupabaseConfigured() && supabase) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const { data, error } = await supabase.functions.invoke('automation-runner', {
        body: { automation_id: automation.id },
        headers: {
          Authorization: session?.access_token ? `Bearer ${session.access_token}` : ''
        }
      });
      if (error) throw error;
      return data;
    } catch (err) {
      console.warn('Backend automation-runner failed, running locally:', err);
    }
  }

  // Local execution fallback
  const at = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return {
    status: 'Success',
    summary: `${automation.name} executed successfully at ${at}`,
    executed_at: new Date().toISOString()
  };
}

export async function saveAutomationToCloud(automation) {
  if (!isSupabaseConfigured() || !supabase) return;
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase.from('automations').upsert({
      id: typeof automation.id === 'string' && automation.id.includes('-') ? automation.id : undefined,
      user_id: user.id,
      name: automation.name,
      trigger_type: automation.trigger,
      trigger_time: automation.time || '07:00',
      action_type: automation.action,
      is_active: automation.on,
      last_run_at: automation.lastRun || null,
      last_status: automation.last || 'Never'
    });
  } catch (err) {
    console.warn('Cloud automation sync error:', err);
  }
}
