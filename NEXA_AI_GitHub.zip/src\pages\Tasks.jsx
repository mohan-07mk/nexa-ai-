import React, { useState, useMemo } from 'react';
import { Ic } from '../components/Icon';
import { today, fmt, nextDate } from '../utils/helpers';
import { saveTask, deleteTask } from '../services/taskService';

export default function Tasks({ tasks, setTasks, log }) {
  const [view, setView] = useState("Today");
  const [q, setQ] = useState("");
  const blank = { title: "", date: today(), time: "09:00", pri: "Medium", repeat: "none" };
  const [f, setF] = useState(blank);

  const list = useMemo(() => tasks.filter(t => {
    if (q && !t.title.toLowerCase().includes(q.toLowerCase())) return false;
    if (view === "Today") return t.date === today() || (!t.done && t.date < today());
    if (view === "Upcoming") return !t.done && t.date > today();
    if (view === "Completed") return t.done;
    return true;
  }).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time)), [tasks, view, q]);

  const add = async (e) => {
    e.preventDefault();
    if (!f.title.trim()) return;

    if (f.id) {
      setTasks(t => t.map(y => y.id === f.id ? f : y));
      await saveTask(f);
      log("Task updated", f.title);
    } else {
      const newTask = { ...f, id: Date.now(), cat: "General", done: false };
      setTasks(t => [...t, newTask]);
      await saveTask(newTask);
      log("Task created", f.title);
    }
    setF(blank);
  };

  const toggle = async (t) => {
    const updated = { ...t, done: !t.done };
    const shouldSpawnNext = !t.done && t.repeat && t.repeat !== "none";
    const nextTask = shouldSpawnNext ? {
      ...t,
      id: Date.now(),
      done: false,
      date: nextDate(t.date, t.repeat)
    } : null;

    setTasks(x => {
      const n = x.map(y => y.id === t.id ? updated : y);
      return nextTask ? [...n, nextTask] : n;
    });

    await saveTask(updated);
    if (nextTask) await saveTask(nextTask);

    if (!t.done) {
      log("Task completed", t.title + (shouldSpawnNext ? ` (next ${t.repeat} occurrence created)` : ""));
    }
  };

  const remove = async (t) => {
    setTasks(x => x.filter(y => y.id !== t.id));
    await deleteTask(t.id);
    log("Task deleted", t.title);
  };

  const pc = { High: "#F87171", Medium: "#FBBF24", Low: "#4ADE80" };

  return (
    <div className="max-w-3xl mx-auto grid gap-4">
      <form onSubmit={add} className="card p-4 grid gap-2 sm:grid-cols-[1fr_auto_auto_auto_auto_auto]">
        <input className="inp" placeholder="Add a task or reminder" value={f.title} onChange={e => setF({ ...f, title: e.target.value })} />
        <input className="inp" type="date" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} />
        <input className="inp" type="time" value={f.time} onChange={e => setF({ ...f, time: e.target.value })} />
        <select className="inp" value={f.pri} onChange={e => setF({ ...f, pri: e.target.value })}>
          {["High", "Medium", "Low"].map(p => <option key={p}>{p}</option>)}
        </select>
        <select className="inp" aria-label="Repeat" value={f.repeat || "none"} onChange={e => setF({ ...f, repeat: e.target.value })}>
          {["none", "daily", "weekdays", "weekly", "monthly"].map(p => (
            <option key={p} value={p}>{p === "none" ? "No repeat" : "Repeat " + p}</option>
          ))}
        </select>
        <div className="flex gap-2">
          <button className="btn btn-p" type="submit">{f.id ? "Save" : "Add task"}</button>
          {f.id && <button type="button" className="btn" onClick={() => setF(blank)}>Cancel</button>}
        </div>
      </form>

      <div className="flex flex-wrap gap-2 items-center">
        {["Today", "Upcoming", "Completed", "All"].map(v => (
          <button
            key={v}
            className="btn"
            style={view === v ? { background: "rgba(139,92,246,.2)", borderColor: "var(--pu)" } : {}}
            onClick={() => setView(v)}
          >
            {v}
          </button>
        ))}
        <input className="inp flex-1 min-w-[140px]" placeholder="Search tasks…" value={q} onChange={e => setQ(e.target.value)} />
      </div>

      <div className="grid gap-2">
        {list.length === 0 && (
          <div className="card p-8 text-center mu text-sm">No tasks found. Add one above to get organized.</div>
        )}
        {list.map(t => {
          const over = !t.done && t.date < today();
          return (
            <div key={t.id} className="card p-3 flex items-center gap-3">
              <button
                className="w-6 h-6 rounded-full shrink-0 flex items-center justify-center transition-all"
                aria-label="Toggle complete"
                onClick={() => toggle(t)}
                style={{
                  border: "2px solid " + (t.done ? "#4ADE80" : "var(--line)"),
                  background: t.done ? "#4ADE80" : "none",
                  color: "#08090D"
                }}
              >
                {t.done && "✓"}
              </button>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate" style={{ textDecoration: t.done ? "line-through" : "none", opacity: t.done ? 0.5 : 1 }}>
                  {t.title}
                </p>
                <p className="text-xs mu">
                  {t.date} · {fmt(t.time || "09:00")} · <span style={{ color: pc[t.pri || "Medium"] }}>{t.pri || "Medium"}</span>
                  {t.repeat && t.repeat !== "none" && <span> · {t.repeat}</span>}
                  {over && <span style={{ color: "#F87171" }}> · Overdue</span>}
                </p>
              </div>
              <button className="mu text-xs hover:text-white" aria-label="Edit task" style={{ background: "none", border: 0 }} onClick={() => setF(t)}>
                Edit
              </button>
              <button className="mu hover:text-red-400" aria-label="Delete task" style={{ background: "none", border: 0 }} onClick={() => remove(t)}>
                <Ic n="trash" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
