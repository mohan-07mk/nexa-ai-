export const lstr=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
export const today=()=>lstr(new Date());
export const addDays=n=>{const d=new Date();d.setDate(d.getDate()+n);return lstr(d)};
export const fmt=t=>{const [h,m]=t.split(":").map(Number);return `${((h+11)%12)+1}:${String(m).padStart(2,"0")} ${h<12?"AM":"PM"}`};
export const DN=["S","M","T","W","T","F","S"];
export const nextDate=(d,r)=>{const x=new Date(d+"T00:00");if(r==="daily")x.setDate(x.getDate()+1);else if(r==="weekdays"){do{x.setDate(x.getDate()+1)}while([0,6].includes(x.getDay()))}else if(r==="weekly")x.setDate(x.getDate()+7);else if(r==="monthly")x.setMonth(x.getMonth()+1);return lstr(x)};
