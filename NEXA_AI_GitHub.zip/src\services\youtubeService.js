// ==============================================================================
// NEXA AI — YOUTUBE INTELLIGENCE SERVICE
// Handles channel resolution, RSS/API latest video polling, backend monitor integration,
// and Supabase channel persistence.
// ==============================================================================

import { supabase, isSupabaseConfigured } from './supabaseClient.js';

// Helper to extract channel info from URL or ID
export function parseYouTubeInput(input) {
  const str = input.trim();
  const handleMatch = str.match(/(?:@|channel\/|c\/|user\/)([\w.-]+)/i) || str.match(/^([\w.-]{3,})$/);
  const name = handleMatch ? handleMatch[1] : str.replace(/^https?:\/\/(www\.)?youtube\.com\/?/i, '');
  const isChannelId = /^UC[\w-]{22}$/.test(name);
  const cleanUrl = str.startsWith('http') ? str : `https://youtube.com/@${name}`;

  return {
    channelId: isChannelId ? name : name,
    channelName: name,
    url: cleanUrl
  };
}

// Fetch latest video for a channel using YouTube RSS (Zero Quota / Public)
export async function fetchChannelLatestVideo(channelInput) {
  const { channelId, channelName, url } = parseYouTubeInput(channelInput);

  try {
    // Try public RSS feed via CORS-friendly proxy or directly
    const rssFeedUrl = channelId.startsWith('UC')
      ? `https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`
      : `https://www.youtube.com/feeds/videos.xml?user=${channelName}`;

    // Try direct fetch first (works natively in Node, Android Capacitor, and Edge Functions)
    let xml = null;
    try {
      const directRes = await fetch(rssFeedUrl, { signal: AbortSignal.timeout(4000) });
      if (directRes.ok) {
        xml = await directRes.text();
      }
    } catch (_) {
      // Fallback to proxy if direct blocked by web browser CORS
      try {
        const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(rssFeedUrl)}`;
        const res = await fetch(proxyUrl, { signal: AbortSignal.timeout(4000) });
        if (res.ok) {
          const data = await res.json();
          xml = data.contents;
        }
      } catch (proxyErr) {
        // Continue to fallback
      }
    }

    if (xml) {
      const entryMatch = xml.match(/<entry>([\s\S]*?)<\/entry>/);
      if (entryMatch) {
        const entry = entryMatch[1];
        const vidMatch = entry.match(/<yt:videoId>([^<]+)<\/yt:videoId>/);
        const titleMatch = entry.match(/<title>([^<]+)<\/title>/);
        const pubMatch = entry.match(/<published>([^<]+)<\/published>/);
        const thumbMatch = entry.match(/<media:thumbnail url="([^"]+)"/);

        if (vidMatch && titleMatch) {
          return {
            id: vidMatch[1],
            title: titleMatch[1].replace(/&amp;/g, '&').replace(/&quot;/g, '"'),
            date: pubMatch ? pubMatch[1].split('T')[0] : new Date().toISOString().split('T')[0],
            thumbnail: thumbMatch ? thumbMatch[1] : `https://img.youtube.com/vi/${vidMatch[1]}/hqdefault.jpg`,
            url: `https://www.youtube.com/watch?v=${vidMatch[1]}`,
            isNew: true
          };
        }
      }
    }
  } catch (err) {
    console.warn(`RSS fetch for ${channelName} failed, falling back to simulated info:`, err);
  }

  // Graceful fallback video preview
  return {
    id: `demo_${Date.now()}`,
    title: `Latest updates from @${channelName}`,
    date: new Date().toISOString().split('T')[0],
    thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&q=80',
    url: url,
    isNew: false
  };
}

// Trigger backend Edge Function 'youtube-monitor'
export async function triggerYouTubeMonitorCheck() {
  if (isSupabaseConfigured() && supabase) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const { data, error } = await supabase.functions.invoke('youtube-monitor', {
        headers: {
          Authorization: session?.access_token ? `Bearer ${session.access_token}` : ''
        }
      });
      if (error) throw error;
      return data;
    } catch (err) {
      console.warn('Backend youtube-monitor invoke failed:', err);
    }
  }
  return { message: 'Checked locally', new_videos_count: 0 };
}

// Save channel to Supabase
export async function saveChannelToCloud(channel) {
  if (!isSupabaseConfigured() || !supabase) return;
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase.from('youtube_channels').upsert({
      user_id: user.id,
      channel_id: channel.channelId || channel.name,
      channel_name: channel.name,
      channel_url: channel.url,
      notify_enabled: channel.notify ?? true
    }, { onConflict: 'user_id, channel_id' });
  } catch (err) {
    console.warn('Failed to save channel to Supabase:', err);
  }
}
