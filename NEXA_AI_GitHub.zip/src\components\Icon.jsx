import {Home,MessageSquare,CheckSquare,Clock,List,Send,Plus,Trash2,Youtube,Calendar,Zap,StickyNote,Settings,Mic,MicOff,Volume2,Square,CheckCheck,RefreshCw} from 'lucide-react';
const M={home:Home,chat:MessageSquare,check:CheckSquare,clock:Clock,list:List,send:Send,plus:Plus,trash:Trash2,yt:Youtube,cal:Calendar,bolt:Zap,note:StickyNote,gear:Settings,mic:Mic,micoff:MicOff,vol:Volume2,stop:Square,checkall:CheckCheck,refresh:RefreshCw};
export const Ic=({n,s=18})=>{const C=M[n]||List;return <C size={s} strokeWidth={2}/>};
