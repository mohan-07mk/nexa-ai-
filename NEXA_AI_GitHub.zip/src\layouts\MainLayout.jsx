import {NavLink,Outlet,useLocation} from 'react-router-dom';
import {NAV} from '../data/nav';
import {Ic} from '../components/Icon';
export default function MainLayout(){
  const {pathname}=useLocation();
  const cur=NAV.find(n=>"/"+n[0]===pathname)||NAV[0];
  return(<div className="flex h-full">
    <aside className="hidden md:flex flex-col w-60 shrink-0 p-4 gap-1 overflow-y-auto" style={{background:"var(--bg2)",borderRight:"1px solid var(--line)"}}>
      <div className="flex items-center gap-2 px-2 py-3 mb-2"><div className="w-8 h-8 rounded-xl" style={{background:"linear-gradient(135deg,var(--pu),var(--cy))"}}/><span className="font-extrabold tracking-tight text-lg">NEXA AI</span></div>
      {NAV.map(([k,l,i])=><NavLink key={k} to={"/"+k} className={({isActive})=>"nav-a "+(isActive?"on":"")}><Ic n={i}/>{l}</NavLink>)}
      <div className="mt-auto p-3 rounded-xl" style={{background:"var(--card)",border:"1px solid var(--line)"}}>
        <div className="flex items-center gap-1.5 text-xs font-semibold" style={{color:"#4ADE80"}}>
          <span className="w-2 h-2 rounded-full" style={{background:"#4ADE80"}}/>
          <span>AI Agent Active</span>
        </div>
        <p className="mu text-[11px] mt-1">Capacitor Android & Supabase Backend Ready</p>
      </div>
    </aside>
    <div className="flex-1 min-w-0 flex flex-col">
      <header className="flex items-center justify-between px-4 md:px-8 py-4" style={{borderBottom:"1px solid var(--line)"}}>
        <div><h1 className="text-xl font-bold">{cur[1]}</h1><p className="mu text-xs">{new Date().toLocaleDateString(undefined,{weekday:"long",day:"numeric",month:"long"})}</p></div>
        <span className="text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1.5" style={{background:"rgba(74,222,128,.12)",color:"#4ADE80"}}>
          <span className="w-1.5 h-1.5 rounded-full" style={{background:"#4ADE80"}}/>
          Online · Android Ready
        </span>
      </header>
      <main className="flex-1 min-h-0 overflow-y-auto p-4 md:p-8 pb-24 md:pb-8"><Outlet/></main>
    </div>
    <nav className="md:hidden fixed bottom-0 inset-x-0 glass flex overflow-x-auto py-2" style={{borderTop:"1px solid var(--line)",paddingBottom:"calc(.5rem + env(safe-area-inset-bottom,0px))"}}>
      {NAV.map(([k,l,i])=><NavLink key={k} to={"/"+k} aria-label={l} className="flex flex-col items-center gap-1 text-[10px] font-semibold px-3 shrink-0 flex-1" style={({isActive})=>({color:isActive?"var(--tx)":"var(--mu)"})}>
        {({isActive})=><><span className="p-1.5 rounded-xl" style={{background:isActive?"rgba(139,92,246,.25)":"transparent"}}><Ic n={i} s={20}/></span>{l.split(" ")[0]}</>}</NavLink>)}
    </nav></div>);
}
