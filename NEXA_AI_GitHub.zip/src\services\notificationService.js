// ==============================================================================
// NEXA AI — NOTIFICATION SERVICE (LOCAL ON-DEVICE NOTIFICATIONS)
// Manages Android notification channels, runtime permissions, action handlers,
// and exact alarm scheduling with zero external crash dependencies.
// ==============================================================================

import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { supabase, isSupabaseConfigured } from './supabaseClient';

export const isNative = () => Capacitor.isNativePlatform();

// Initialize notification channels and action types for Android
export async function initNotificationService(onActionClick) {
  if (!isNative()) {
    console.log('Web platform: standard browser notifications enabled.');
    return;
  }

  // 1. Create Android Notification Channels safely
  try {
    await LocalNotifications.createChannel({
      id: 'nexa-alarms',
      name: 'NEXA Alarms',
      description: 'Critical alarm notifications with custom sound and vibration',
      importance: 5, // MAX importance (heads-up notification)
      visibility: 1, // Public on lockscreen
      sound: 'beep.wav',
      vibration: true,
      lights: true,
      lightColor: '#8B5CF6'
    });
  } catch (e) {
    console.warn('Failed creating nexa-alarms channel:', e);
  }

  try {
    await LocalNotifications.createChannel({
      id: 'nexa-reminders',
      name: 'NEXA Reminders',
      description: 'Scheduled reminders for tasks and routines',
      importance: 4,
      visibility: 1,
      sound: 'beep.wav',
      vibration: true
    });
  } catch (e) {
    console.warn('Failed creating nexa-reminders channel:', e);
  }

  try {
    await LocalNotifications.createChannel({
      id: 'nexa-youtube',
      name: 'NEXA YouTube Alerts',
      description: 'New video alerts from monitored channels',
      importance: 3,
      visibility: 0
    });
  } catch (e) {
    console.warn('Failed creating nexa-youtube channel:', e);
  }

  try {
    await LocalNotifications.createChannel({
      id: 'nexa-automations',
      name: 'NEXA Automations',
      description: 'Daily briefing and automation updates',
      importance: 3,
      visibility: 0
    });
  } catch (e) {
    console.warn('Failed creating nexa-automations channel:', e);
  }

  // 2. Register Action Types (Snooze and Dismiss buttons on alarm notification)
  try {
    await LocalNotifications.registerActionTypes({
      types: [
        {
          id: 'ALARM_ACTIONS',
          actions: [
            { id: 'snooze', title: 'Snooze (5 min)' },
            { id: 'dismiss', title: 'Dismiss Alarm', destructive: true }
          ]
        },
        {
          id: 'REMINDER_ACTIONS',
          actions: [
            { id: 'complete', title: 'Mark Done' },
            { id: 'snooze', title: 'Snooze' }
          ]
        }
      ]
    });
  } catch (e) {
    console.warn('Failed registering action types:', e);
  }

  // 3. Listen to local notification actions safely
  try {
    await LocalNotifications.addListener('localNotificationActionPerformed', (notificationAction) => {
      console.log('Notification action performed:', notificationAction);
      if (onActionClick) {
        try {
          onActionClick(notificationAction);
        } catch (actionErr) {
          console.warn('Error handling notification action:', actionErr);
        }
      }
    });
  } catch (e) {
    console.warn('Failed adding notification listener:', e);
  }

  // 4. Request runtime permission if prompt is needed
  try {
    const status = await LocalNotifications.checkPermissions();
    if (status.display === 'prompt') {
      await LocalNotifications.requestPermissions();
    }
  } catch (permErr) {
    console.warn('Permission check notice:', permErr);
  }
}

// Check and request notification permissions
export async function requestNotificationPermission() {
  if (isNative()) {
    try {
      const status = await LocalNotifications.requestPermissions();
      return status.display === 'granted';
    } catch (err) {
      console.error('Error requesting native notification permission:', err);
      return false;
    }
  } else if (typeof window !== 'undefined' && 'Notification' in window) {
    try {
      const res = await Notification.requestPermission();
      return res === 'granted';
    } catch (_) {
      return false;
    }
  }
  return false;
}

// Local notifications provides on-device notifications
export async function setupPushNotifications() {
  // Push notification stub — full on-device local notifications active
  return true;
}
