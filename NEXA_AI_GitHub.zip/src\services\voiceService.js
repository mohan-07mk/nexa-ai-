// ==============================================================================
// NEXA AI — VOICE ASSISTANT SERVICE (STT & TTS)
// Handles microphone permissions, speech recognition in Tamil & Thanglish (en-IN / ta-IN),
// and text-to-speech audio playback with pause/stop controls.
// ==============================================================================

const SpeechRecognition = typeof window !== 'undefined'
  ? window.SpeechRecognition || window.webkitSpeechRecognition
  : null;

export const isSTTSupported = () => Boolean(SpeechRecognition);
export const isTTSSupported = () => typeof window !== 'undefined' && 'speechSynthesis' in window;

let activeRecognition = null;

// Start voice recognition
export function startVoiceRecognition({
  lang = 'en-IN', // 'en-IN' for Thanglish/Indian English, or 'ta-IN' for Tamil
  onResult,
  onError,
  onEnd
}) {
  if (!isSTTSupported()) {
    if (onError) onError(new Error('Speech recognition is not supported on this browser/device.'));
    return null;
  }

  try {
    if (activeRecognition) {
      activeRecognition.abort();
    }

    const recognition = new SpeechRecognition();
    recognition.lang = lang;
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      let finalTranscript = '';
      let interimTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }

      if (onResult) {
        onResult({
          transcript: finalTranscript || interimTranscript,
          isFinal: Boolean(finalTranscript)
        });
      }
    };

    recognition.onerror = (event) => {
      console.warn('Speech recognition error:', event.error);
      if (onError) onError(event);
    };

    recognition.onend = () => {
      activeRecognition = null;
      if (onEnd) onEnd();
    };

    recognition.start();
    activeRecognition = recognition;
    return recognition;
  } catch (err) {
    console.error('Failed to start speech recognition:', err);
    if (onError) onError(err);
    return null;
  }
}

// Stop voice recognition
export function stopVoiceRecognition() {
  if (activeRecognition) {
    try {
      activeRecognition.stop();
    } catch (_) {}
    activeRecognition = null;
  }
}

// Text to Speech playback
export function speakText(text, { lang = 'en-IN', rate = 1.0, onEnd } = {}) {
  if (!isTTSSupported()) return;

  try {
    window.speechSynthesis.cancel(); // Stop prior speech

    // Strip markdown formatting for natural voice output
    const cleanText = text
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/\*([^*]+)\*/g, '$1')
      .replace(/[`_#]/g, '')
      .replace(/https?:\/\/\S+/g, '')
      .trim();

    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = lang;
    utterance.rate = rate;

    // Pick best available voice matching locale if possible
    const voices = window.speechSynthesis.getVoices();
    const matchingVoice = voices.find(v => v.lang.startsWith(lang.split('-')[0])) ||
                          voices.find(v => v.lang === 'en-IN') ||
                          voices.find(v => v.lang.startsWith('en'));
    if (matchingVoice) {
      utterance.voice = matchingVoice;
    }

    if (onEnd) {
      utterance.onend = onEnd;
      utterance.onerror = onEnd;
    }

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn('Text-to-speech error:', err);
  }
}

// Stop speaking
export function stopSpeaking() {
  if (isTTSSupported()) {
    try {
      window.speechSynthesis.cancel();
    } catch (_) {}
  }
}

