// ==============================================================================
// NEXA AI — TASK & TODO SERVICE
// Manages tasks CRUD, priority, recurrence, local reminders, and Supabase sync
// ==============================================================================

import { supabase, isSupabaseConfigured } from './supabaseClient.js';
import { scheduleLocalReminder, cancelLocalReminder } from './reminderService.js';
import { nextDate } from '../utils/helpers.js';

export async function fetchTasksFromCloud() {
  if (!isSupabaseConfigured() || !supabase) return null;
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .eq('user_id', user.id)
      .order('date', { ascending: true })
      .order('time', { ascending: true });

    if (error) throw error;
    return data;
  } catch (err) {
    console.warn('Failed to fetch tasks from Supabase:', err);
    return null;
  }
}

export async function saveTask(task) {
  // 1. Schedule local reminder if task has time and isn't done
  if (!task.done && task.time) {
    scheduleLocalReminder(task).catch(console.warn);
  } else {
    cancelLocalReminder(task.id).catch(console.warn);
  }

  // 2. Cloud sync if Supabase is connected
  if (isSupabaseConfigured() && supabase) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase.from('tasks').upsert({
          id: typeof task.id === 'string' && task.id.includes('-') ? task.id : undefined,
          user_id: user.id,
          title: task.title,
          date: task.date,
          time: task.time || '09:00',
          priority: task.pri || task.priority || 'Medium',
          category: task.cat || task.category || 'General',
          repeat: task.repeat || 'none',
          done: Boolean(task.done),
          completed_at: task.done ? new Date().toISOString() : null
        });
      }
    } catch (err) {
      console.warn('Failed to sync task to Supabase:', err);
    }
  }

  return task;
}

export async function deleteTask(taskId) {
  cancelLocalReminder(taskId).catch(console.warn);

  if (isSupabaseConfigured() && supabase) {
    try {
      if (typeof taskId === 'string' && taskId.includes('-')) {
        await supabase.from('tasks').delete().eq('id', taskId);
      }
    } catch (err) {
      console.warn('Failed to delete task from Supabase:', err);
    }
  }
}
