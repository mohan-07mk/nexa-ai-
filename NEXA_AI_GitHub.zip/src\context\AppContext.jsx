import { createContext, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import useStore from '../hooks/useStore';
import { SEED_TASKS, SEED_ALARMS, SEED_ACT, SEED_YT, SEED_EV, SEED_AUTO, SEED_NOTES, SEED_SET } from '../data/seed';
import { initNotificationService } from '../services/notificationService';
import { syncAllAlarms, snoozeAlarm, cancelNativeAlarm } from '../services/alarmService';

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

export function AppProvider({ children }) {
  const [tasks, setTasks] = useStore("nexa.tasks", SEED_TASKS);
  const [alarms, setAlarms] = useStore("nexa.alarms", SEED_ALARMS);
  const [act, setAct] = useStore("nexa.act", SEED_ACT);
  const [yt, setYt] = useStore("nexa.yt", SEED_YT);
  const [ev, setEv] = useStore("nexa.ev", SEED_EV);
  const [autos, setAutos] = useStore("nexa.autos", SEED_AUTO);
  const [notes, setNotes] = useStore("nexa.notes", SEED_NOTES);
  const [set, setSet] = useStore("nexa.settings", SEED_SET);
  const [draft, setDraft] = useStore("nexa.draft", "");
  const navigate = useNavigate();

  const go = p => navigate("/" + p);
  const log = (name, desc, status = "Success") =>
    setAct(a => [{ id: Date.now(), name, desc, status, at: "Just now" }, ...a]);

  // App initialization on mobile / web startup
  useEffect(() => {
    try {
      // 1. Initialize notification channels and action listeners
      initNotificationService((notificationAction) => {
        try {
          const actionId = notificationAction.actionId;
          const extra = notificationAction.notification?.extra;

          if (extra?.type === 'alarm' || extra?.type === 'alarm_snooze') {
            if (actionId === 'snooze') {
              snoozeAlarm(extra.alarmId, extra.snoozeMins || 5);
              log("Alarm snoozed", `Snoozed for ${extra.snoozeMins || 5} min`);
            } else if (actionId === 'dismiss') {
              cancelNativeAlarm(extra.alarmId);
              log("Alarm dismissed", "Alarm dismissed from notification");
            }
          }
        } catch (actErr) {
          console.warn('Action listener error:', actErr);
        }
      }).catch(err => console.warn('Notification init warning:', err));
    } catch (e) {
      console.warn('Error launching notification service:', e);
    }

    try {
      // 2. Reschedule native alarms with Android AlarmManager
      syncAllAlarms(alarms).catch(err => console.warn('Alarm sync warning:', err));
    } catch (e) {
      console.warn('Error launching alarm sync:', e);
    }
  }, []);

  return (
    <Ctx.Provider
      value={{
        tasks,
        setTasks,
        alarms,
        setAlarms,
        act,
        log,
        go,
        draft,
        setDraft,
        yt,
        setYt,
        ev,
        setEv,
        autos,
        setAutos,
        notes,
        setNotes,
        set,
        setSet
      }}
    >
      {children}
    </Ctx.Provider>
  );
}
