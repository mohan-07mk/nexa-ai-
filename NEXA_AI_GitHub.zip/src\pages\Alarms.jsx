import React, { useState, useEffect } from 'react';
import { Ic } from '../components/Icon';
import { DN, fmt } from '../utils/helpers';
import Stopwatch from '../components/Stopwatch';
import { scheduleNativeAlarm, cancelNativeAlarm, playWebAlarmSound, saveAlarmToCloud, isNative } from '../services/alarmService';

export default function Alarms({ alarms, setAlarms, log }) {
  const [f, setF] = useState({ time: "07:00", label: "", days: [], sound: "Gentle", snooze: 5 });
  const [secs, setSecs] = useState(300);
  const [run, setRun] = useState(false);

  useEffect(() => {
    if (!run) return;
    const i = setInterval(() => setSecs(s => {
      if (s <= 1) {
        setRun(false);
        playWebAlarmSound();
        return 0;
      }
      return s - 1;
    }), 1000);
    return () => clearInterval(i);
  }, [run]);

  const add = async (e) => {
    e.preventDefault();
    const newAlarm = {
      ...f,
      label: f.label || "Alarm",
      id: Date.now(),
      on: true
    };
    setAlarms(a => [...a, newAlarm]);
    await scheduleNativeAlarm(newAlarm);
    await saveAlarmToCloud(newAlarm);
    log("Alarm configured", `${newAlarm.label} · ${fmt(newAlarm.time)} (Android Native Scheduled)`);
    setF({ time: "07:00", label: "", days: [], sound: "Gentle", snooze: 5 });
  };

  const toggleAlarm = async (alarm) => {
    const updated = { ...alarm, on: !alarm.on };
    setAlarms(x => x.map(y => y.id === alarm.id ? updated : y));
    if (updated.on) {
      await scheduleNativeAlarm(updated);
      log("Alarm enabled", `${updated.label} · ${fmt(updated.time)}`);
    } else {
      await cancelNativeAlarm(alarm.id);
      log("Alarm disabled", `${updated.label} · ${fmt(updated.time)}`);
    }
    await saveAlarmToCloud(updated);
  };

  const deleteAlarm = async (alarm) => {
    setAlarms(x => x.filter(y => y.id !== alarm.id));
    await cancelNativeAlarm(alarm.id);
    log("Alarm deleted", alarm.label);
  };

  const tgl = d => setF(x => ({
    ...x,
    days: x.days.includes(d) ? x.days.filter(y => y !== d) : [...x.days, d]
  }));

  return (
    <div className="max-w-3xl mx-auto grid gap-4">
      {/* Native integration status banner */}
      <div className="card p-3 flex items-center justify-between text-xs" style={{ background: "rgba(139,92,246,.12)", borderColor: "var(--pu)" }}>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: "#4ADE80" }} />
          <span>{isNative() ? "Android AlarmManager Active · Exact Alarms & WakeLock enabled" : "Web Preview Mode · Native Android alarm channel ready for APK"}</span>
        </div>
        <button className="btn text-xs py-1 px-2.5" onClick={playWebAlarmSound}>
          Test Sound
        </button>
      </div>

      <form onSubmit={add} className="card p-4 grid gap-3">
        <div className="flex gap-2 flex-wrap sm:flex-nowrap">
          <input className="inp" type="time" value={f.time} onChange={e => setF({ ...f, time: e.target.value })} />
          <input className="inp flex-1" placeholder="Label (optional)" value={f.label} onChange={e => setF({ ...f, label: e.target.value })} />
          <select className="inp" aria-label="Alarm sound" value={f.sound} onChange={e => setF({ ...f, sound: e.target.value })}>
            {["Gentle", "Classic", "Rise", "Digital"].map(s => <option key={s}>{s}</option>)}
          </select>
          <select className="inp" aria-label="Snooze" value={f.snooze} onChange={e => setF({ ...f, snooze: +e.target.value })}>
            {[0, 5, 10, 15].map(n => <option key={n} value={n}>{n ? "Snooze " + n + " min" : "No snooze"}</option>)}
          </select>
        </div>
        <div className="flex gap-1.5 items-center flex-wrap">
          {DN.map((d, i) => (
            <button
              type="button"
              key={i}
              aria-label={"Repeat day " + i}
              onClick={() => tgl(i)}
              className="w-8 h-8 rounded-full text-xs font-bold transition-all"
              style={{
                border: "1px solid var(--line)",
                background: f.days.includes(i) ? "var(--pu)" : "var(--bg2)",
                color: "var(--tx)"
              }}
            >
              {d}
            </button>
          ))}
          <button className="btn btn-p ml-auto" type="submit">Add alarm</button>
        </div>
      </form>

      {alarms.length === 0 && (
        <div className="card p-8 text-center mu text-sm">No alarms yet. Add one above.</div>
      )}

      {alarms.map(a => (
        <div key={a.id} className="card p-4 flex items-center gap-3" style={{ opacity: a.on ? 1 : 0.55 }}>
          <div className="flex-1 min-w-0">
            <p className="text-3xl font-extrabold tracking-tight">{fmt(a.time)}</p>
            <p className="text-xs mu truncate">
              {a.label} · {a.sound || "Gentle"} · {a.snooze === 0 ? "no snooze" : (a.snooze || 5) + " min snooze"} · {a.days.length === 0 ? "Once" : a.days.length === 7 ? "Every day" : a.days.map(d => DN[d]).join(" ")}
            </p>
          </div>
          <button className={"tog " + (a.on ? "on" : "")} aria-label="Toggle alarm" onClick={() => toggleAlarm(a)} />
          <button className="mu hover:text-red-400" aria-label="Delete alarm" style={{ background: "none", border: 0 }} onClick={() => deleteAlarm(a)}>
            <Ic n="trash" />
          </button>
        </div>
      ))}

      {/* Timer & Stopwatch */}
      <div className="card p-4 flex items-center gap-3 flex-wrap">
        <div className="flex-1">
          <p className="mu text-xs">Countdown timer</p>
          <p className="text-3xl font-extrabold tabular-nums">
            {String(Math.floor(secs / 60)).padStart(2, "0")}:{String(secs % 60).padStart(2, "0")}
          </p>
        </div>
        <button className="btn" onClick={() => setSecs(s => s + 60)}>+1 min</button>
        <button className="btn btn-p" onClick={() => setRun(r => !r)}>{run ? "Pause" : "Start"}</button>
        <button className="btn" onClick={() => { setRun(false); setSecs(300); }}>Reset</button>
      </div>

      <Stopwatch />
    </div>
  );
}
