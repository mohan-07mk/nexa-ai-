package com.mohan.nexaai;

import android.os.Bundle;
import android.util.Log;
import com.getcapacitor.BridgeActivity;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends BridgeActivity {
    private static final String TAG = "NEXA_AI_MAIN";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Install global uncaught exception guard to prevent instant crashes
        final Thread.UncaughtExceptionHandler defaultHandler = Thread.getDefaultUncaughtExceptionHandler();

        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, Throwable throwable) {
                try {
                    StringWriter sw = new StringWriter();
                    throwable.printStackTrace(new PrintWriter(sw));
                    String stackTrace = sw.toString();

                    Log.e(TAG, "FATAL EXCEPTION INTERCEPTED on thread: " + thread.getName(), throwable);

                    // Write to persistent crash log file
                    File logDir = getExternalFilesDir(null);
                    if (logDir == null) {
                        logDir = getFilesDir();
                    }
                    File logFile = new File(logDir, "nexa_crash_log.txt");
                    FileWriter writer = new FileWriter(logFile, true);
                    String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
                    writer.write("=== CRASH AT " + timestamp + " ===\n");
                    writer.write("Thread: " + thread.getName() + " (id: " + thread.getId() + ")\n");
                    writer.write(stackTrace + "\n\n");
                    writer.flush();
                    writer.close();
                    Log.i(TAG, "Crash log written to: " + logFile.getAbsolutePath());

                    // Check if it's a known non-fatal startup/notification/firebase exception
                    boolean isRecoverable = stackTrace.contains("Firebase") ||
                                          stackTrace.contains("PushNotification") ||
                                          stackTrace.contains("NotificationChannel") ||
                                          stackTrace.contains("ExactAlarm") ||
                                          stackTrace.contains("canScheduleExactAlarms");

                    if (isRecoverable) {
                        Log.w(TAG, "Recoverable initialization exception suppressed to keep NEXA AI alive.");
                        return;
                    }
                } catch (Exception writeEx) {
                    Log.e(TAG, "Failed writing crash log", writeEx);
                }

                // If unrecoverable, delegate to system default
                if (defaultHandler != null) {
                    defaultHandler.uncaughtException(thread, throwable);
                }
            }
        });

        super.onCreate(savedInstanceState);
        Log.i(TAG, "NEXA AI MainActivity created successfully on Android " + android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + ")");
    }
}
