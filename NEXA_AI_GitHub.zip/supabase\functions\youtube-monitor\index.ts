// ==============================================================================
// NEXA AI — YOUTUBE MONITOR EDGE FUNCTION
// Supabase Edge Function: youtube-monitor
// Responsibilities:
// - Fetches all monitored channels from 'youtube_channels' table
// - Retrieves latest video via YouTube Data API v3 or YouTube XML RSS feeds
// - Detects newly published videos and deduplicates using 'youtube_videos' table
// - Dispatches Push Notifications via Firebase Cloud Messaging (FCM) to user devices
// - Logs execution and new discovery in 'activity_logs'
// ==============================================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const youtubeApiKey = Deno.env.get("YOUTUBE_API_KEY") ?? "";
    const fcmServerKey = Deno.env.get("FCM_SERVER_KEY") ?? "";

    if (!supabaseUrl || !serviceRoleKey) {
      return new Response(JSON.stringify({ error: "Missing Supabase credentials in Edge Function environment" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey);

    // Optional user_id filter if triggered manually from client
    let targetUserId: string | null = null;
    try {
      const body = await req.json();
      if (body?.user_id) targetUserId = body.user_id;
    } catch (_) {
      // Background cron call without body
    }

    // Query active monitored channels
    let query = supabase
      .from("youtube_channels")
      .select("*")
      .eq("notify_enabled", true);

    if (targetUserId) {
      query = query.eq("user_id", targetUserId);
    }

    const { data: channels, error: chError } = await query;

    if (chError) {
      throw chError;
    }

    if (!channels || channels.length === 0) {
      return new Response(JSON.stringify({ message: "No active channels to monitor", checked: 0, new_videos: 0 }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    let totalNewVideos = 0;
    const discoveries: any[] = [];

    for (const ch of channels) {
      try {
        let latestVideo: { id: string; title: string; publishedAt: string; thumbnail: string; url: string } | null = null;

        // Method 1: YouTube Data API v3 if API key is provided
        if (youtubeApiKey && ch.channel_id.startsWith("UC")) {
          const ytUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=${ch.channel_id}&maxResults=1&order=date&type=video&key=${youtubeApiKey}`;
          const res = await fetch(ytUrl);
          if (res.ok) {
            const data = await res.json();
            const item = data.items?.[0];
            if (item) {
              latestVideo = {
                id: item.id.videoId,
                title: item.snippet.title,
                publishedAt: item.snippet.publishedAt,
                thumbnail: item.snippet.thumbnails?.high?.url || item.snippet.thumbnails?.default?.url,
                url: `https://www.youtube.com/watch?v=${item.id.videoId}`
              };
            }
          }
        }

        // Method 2: Public YouTube RSS Feed (0 API quota required)
        if (!latestVideo) {
          const rssUrl = ch.channel_id.startsWith("UC") 
            ? `https://www.youtube.com/feeds/videos.xml?channel_id=${ch.channel_id}`
            : `https://www.youtube.com/feeds/videos.xml?user=${ch.channel_name}`;
          
          const rssRes = await fetch(rssUrl);
          if (rssRes.ok) {
            const xml = await rssRes.text();
            // Simple regex parser for RSS XML
            const entryMatch = xml.match(/<entry>([\s\S]*?)<\/entry>/);
            if (entryMatch) {
              const entry = entryMatch[1];
              const vidMatch = entry.match(/<yt:videoId>([^<]+)<\/yt:videoId>/);
              const titleMatch = entry.match(/<title>([^<]+)<\/title>/);
              const pubMatch = entry.match(/<published>([^<]+)<\/published>/);
              const thumbMatch = entry.match(/<media:thumbnail url="([^"]+)"/);

              if (vidMatch && titleMatch) {
                latestVideo = {
                  id: vidMatch[1],
                  title: titleMatch[1].replace(/&amp;/g, "&").replace(/&quot;/g, '"'),
                  publishedAt: pubMatch ? pubMatch[1] : new Date().toISOString(),
                  thumbnail: thumbMatch ? thumbMatch[1] : `https://img.youtube.com/vi/${vidMatch[1]}/hqdefault.jpg`,
                  url: `https://www.youtube.com/watch?v=${vidMatch[1]}`
                };
              }
            }
          }
        }

        // If we found a video, check if it's already in the database
        if (latestVideo) {
          const { data: existing } = await supabase
            .from("youtube_videos")
            .select("id")
            .eq("user_id", ch.user_id)
            .eq("video_id", latestVideo.id)
            .maybeSingle();

          if (!existing) {
            // New video discovered!
            totalNewVideos++;
            const { error: insErr } = await supabase.from("youtube_videos").insert({
              channel_id: ch.id,
              user_id: ch.user_id,
              video_id: latestVideo.id,
              title: latestVideo.title,
              published_at: latestVideo.publishedAt,
              thumbnail_url: latestVideo.thumbnail,
              direct_url: latestVideo.url,
              is_new: true,
              notified: false
            });

            if (!insErr) {
              discoveries.push({
                channel: ch.channel_name,
                title: latestVideo.title,
                url: latestVideo.url
              });

              // Log in activity
              await supabase.from("activity_logs").insert({
                user_id: ch.user_id,
                action_name: "New YouTube Video",
                description: `${ch.channel_name}: ${latestVideo.title}`,
                status: "Success",
                metadata: { video_id: latestVideo.id, url: latestVideo.url }
              });

              // Send FCM Push Notification if configured
              if (fcmServerKey) {
                const { data: tokens } = await supabase
                  .from("device_tokens")
                  .select("token")
                  .eq("user_id", ch.user_id);

                if (tokens && tokens.length > 0) {
                  for (const { token } of tokens) {
                    await fetch("https://fcm.googleapis.com/fcm/send", {
                      method: "POST",
                      headers: {
                        "Content-Type": "application/json",
                        "Authorization": `key=${fcmServerKey}`
                      },
                      body: JSON.stringify({
                        to: token,
                        notification: {
                          title: `New Video: ${ch.channel_name}`,
                          body: latestVideo.title,
                          icon: latestVideo.thumbnail,
                          click_action: latestVideo.url
                        },
                        data: {
                          type: "youtube_video",
                          url: latestVideo.url,
                          channel: ch.channel_name
                        }
                      })
                    }).catch(console.error);
                  }
                  await supabase
                    .from("youtube_videos")
                    .update({ notified: true })
                    .eq("video_id", latestVideo.id)
                    .eq("user_id", ch.user_id);
                }
              }
            }
          }
        }

        // Update channel last_checked_at
        await supabase
          .from("youtube_channels")
          .update({ last_checked_at: new Date().toISOString() })
          .eq("id", ch.id);

      } catch (chErr) {
        console.error(`Error checking channel ${ch.channel_name}:`, chErr);
      }
    }

    return new Response(JSON.stringify({
      message: `Checked ${channels.length} channels. Discovered ${totalNewVideos} new videos.`,
      checked_channels: channels.length,
      new_videos_count: totalNewVideos,
      discoveries
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });

  } catch (error: any) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  }
});

