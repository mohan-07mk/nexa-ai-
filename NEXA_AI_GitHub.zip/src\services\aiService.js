// ==============================================================================
// NEXA AI — GEMINI AI AGENT CLIENT SERVICE
// Handles secure communication with the 'gemini-assistant' Supabase Edge Function,
// local multi-action parsing fallback, 18-tool execution dispatcher, and Asia/Kolkata timezone.
// ==============================================================================

import { supabase, isSupabaseConfigured } from './supabaseClient.js';
import { scheduleNativeAlarm } from './alarmService.js';
import { scheduleLocalReminder } from './reminderService.js';
import { saveTask, deleteTask } from './taskService.js';
import { saveCalendarEventToCloud, createGoogleCalendarEvent } from './calendarService.js';
import { fetchChannelLatestVideo } from './youtubeService.js';
import { today, addDays, fmt, nextDate } from '../utils/helpers.js';

export const AI_CONNECTED = isSupabaseConfigured();

// Main message sender to the AI Agent
export async function sendMessageToAgent(message, history = [], userContext = {}) {
  // If Supabase is connected, call the secure backend Edge Function
  if (isSupabaseConfigured() && supabase) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const { data, error } = await supabase.functions.invoke('gemini-assistant', {
        body: {
          message,
          history: history.slice(-6).map(m => ({ role: m.role, text: m.text })),
          user_context: userContext
        },
        headers: {
          Authorization: session?.access_token ? `Bearer ${session.access_token}` : ''
        }
      });

      if (!error && data) {
        return {
          reply: data.reply,
          actions: data.actions || [],
          source: data.source || 'gemini-assistant'
        };
      }
      console.warn('Edge function invoke returned error or empty data:', error);
    } catch (err) {
      console.warn('Failed to contact Gemini Edge Function, using local parser:', err);
    }
  }

  // Robust Client-Side Thanglish / Tamil Multi-Action Parser Fallback
  return parseThanglishMultiAction(message);
}

// Client-Side Multi-Action Parser for Thanglish, Tamil, and English
export function parseThanglishMultiAction(text) {
  const t = text.toLowerCase();
  const actions = [];

  const todayStr = today();
  const tomorrowStr = addDays(1);
  const targetDate = /naalaiku|tomorrow|நாளை|நாளைக்கு/.test(t) ? tomorrowStr : todayStr;

  // Split multiple clauses (e.g. "Naalaiku 6 AM alarm vai, 9 AM assignment remind pannu, evening 7 PM project work schedule pannu")
  const clauses = text.split(/,|\band\b|\baprom\b|\bappuram\b|\bpinpu\b|மற்றும்|பிறகு/i);

  for (const clause of clauses) {
    const ct = clause.toLowerCase().trim();
    if (!ct) continue;

    // Time regex (supports digits + optional am/pm/mani/மணி)
    const m = ct.match(/(\d{1,2})(?::(\d{2}))?\s*(mani|am|pm|மணி|மணிக்கு)?/i);
    let h = m ? +m[1] : null;
    const min = m && m[2] ? +m[2] : 0;
    const isPm = /evening|night|pm|raat|sayangalam|மாலை|இரவு/.test(ct);
    if (h !== null) {
      if (isPm && h < 12) h += 12;
      if (!isPm && h === 12) h = 0;
    }
    const time = h !== null ? `${String(h).padStart(2, "0")}:${String(min).padStart(2, "0")}` : "09:00";

    // Clean title
    const titleClean = clause
      .replace(/\b(naalaiku|innaiku|tomorrow|today|morning|evening|night|remind(er)?|pannu|panni|vai|podu|set|add|create|task|me|to|every|daily|weekly|please|remember|that|search|google|schedule)\b|\d{1,2}(:\d{2})?\s*(mani|am|pm|மணி|மணிக்கு)?/gi, "")
      .replace(/நாளை|நாளைக்கு|இன்று|காலை|மாலை|இரவு|அலாரம்|வை|ஞாபகப்படுத்து|நினைவூட்டு|திட்டம்|போடு/g, "")
      .replace(/\s+/g, " ")
      .trim() || "Untitled";

    const capitalizedTitle = titleClean.charAt(0).toUpperCase() + titleClean.slice(1);

    // 1. Alarm
    if (/alarm|அலாரம்/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "create_alarm",
        args: { time, label: capitalizedTitle === "Untitled" ? "Alarm" : capitalizedTitle, days: [] },
        status: "pending"
      });
    }
    // 2. Recurring Schedule
    else if (/\b(every|daily|weekly|ஒவ்வொரு|தினமும்)\b/.test(ct) && /remind|schedule|ஞாபகப்படுத்து/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "create_recurring_schedule",
        args: {
          title: capitalizedTitle,
          date: targetDate,
          time,
          repeat: /weekday/.test(ct) ? "weekdays" : /week|monday|tuesday|wednesday|thursday|friday|saturday|sunday|திங்கள்/.test(ct) ? "weekly" : "daily"
        },
        status: "pending"
      });
    }
    // 3. Reminder
    else if (/remind|reminder|ninaivupaduthu|ஞாபகப்படுத்து|நினைவூட்டு/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "create_reminder",
        args: { title: capitalizedTitle, date: targetDate, time },
        status: "pending"
      });
    }
    // 4. Task
    else if (/\btask\b|todo|vela|வேலை|பணி/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "create_task",
        args: { title: capitalizedTitle, date: targetDate, time, priority: "Medium", category: "General" },
        status: "pending"
      });
    }
    // 5. Calendar Event
    else if (/meeting|event|appointment|schedule|சந்திப்பு|திட்டம்/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "create_calendar_event",
        args: { title: capitalizedTitle, date: targetDate, time, category: "Work" },
        status: "pending"
      });
    }
    // 6. Memory
    else if (/remember|ninaivu|save memory|gnyabagam|ஞாபகம்|நினைவு/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "save_memory",
        args: { title: capitalizedTitle, body: clause.trim(), category: "Memory" },
        status: "pending"
      });
    }
    // 7. Daily Schedule query
    else if (/enna schedule|what is my schedule|today's plan|innaiku enna/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "get_daily_schedule",
        args: { date: targetDate },
        status: "pending"
      });
    }
    // 8. YouTube query
    else if (/youtube|video/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "get_latest_channel_videos",
        args: { limit: 5 },
        status: "pending"
      });
    }
    // 9. Web Search
    else if (/search|google|ennanu paaru/.test(ct)) {
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "search_web",
        args: { query: capitalizedTitle },
        status: "pending"
      });
    }
  }

  let reply = "";
  if (actions.length === 0) {
    reply = "Vanakkam! I'm NEXA. You can ask me in Thanglish, Tamil, or English:\n- *Naalaiku morning 6 mani alarm vai*\n- *Innaiku night 9 mani assignment remind pannu*\n- *Naalaiku 6 AM alarm vai, 9 AM meeting remind pannu*\n- *Tomorrow enna schedule irukku?*";
  } else if (actions.length === 1) {
    reply = `Seri! I've recognized this action: **${actions[0].type.replace(/_/g, " ")}**. **Confirm pannalama?**`;
  } else {
    reply = `Seri! I've prepared **${actions.length} actions** from your request:\n${actions.map((a, i) => `${i + 1}. ${a.type.replace(/_/g, " ")} (${a.args.title || a.args.label || a.args.time})`).join('\n')}\n\nReview the cards below and click **Confirm** to execute!`;
  }

  return { reply, actions, source: "nexa-parser" };
}

// Single Action Execution Handler
export async function executeToolAction(action, context) {
  const { type, args } = action;
  const { setAlarms, setTasks, setEv, setNotes, log, tasks, alarms, ev } = context;

  switch (type) {
    case "create_alarm": {
      const newAlarm = {
        id: Date.now(),
        time: args.time,
        label: args.label || "Alarm",
        days: args.days || [],
        sound: args.sound || "Gentle",
        snooze: args.snooze_mins || 5,
        on: true
      };
      setAlarms(prev => [...prev, newAlarm]);
      await scheduleNativeAlarm(newAlarm);
      log("Alarm configured", `${newAlarm.label} · ${fmt(newAlarm.time)} (Native Android scheduled)`);
      return { success: true, message: `Alarm set for ${fmt(newAlarm.time)}` };
    }

    case "create_reminder": {
      const newReminder = {
        id: Date.now(),
        title: args.title,
        date: args.date || today(),
        time: args.time || "09:00",
        pri: "Medium",
        cat: "Reminder",
        repeat: args.repeat || "none",
        done: false
      };
      setTasks(prev => [...prev, newReminder]);
      await scheduleLocalReminder(newReminder);
      await saveTask(newReminder);
      log("Reminder created", `${newReminder.title} · ${newReminder.date} ${fmt(newReminder.time)}`);
      return { success: true, message: `Reminder created for ${newReminder.date} at ${fmt(newReminder.time)}` };
    }

    case "create_task": {
      const newTask = {
        id: Date.now(),
        title: args.title,
        date: args.date || today(),
        time: args.time || "09:00",
        pri: args.priority || "Medium",
        cat: args.category || "General",
        repeat: args.repeat || "none",
        done: false
      };
      setTasks(prev => [...prev, newTask]);
      await saveTask(newTask);
      log("Task created", newTask.title);
      return { success: true, message: `Task "${newTask.title}" added to your list` };
    }

    case "update_task": {
      setTasks(prev => prev.map(t => (t.id === args.task_id || t.title.toLowerCase().includes(args.task_id?.toLowerCase())) ? { ...t, ...args } : t));
      log("Task updated", args.title || "Task");
      return { success: true, message: "Task updated" };
    }

    case "delete_task": {
      setTasks(prev => prev.filter(t => t.id !== args.task_id && !t.title.toLowerCase().includes(args.task_id?.toLowerCase())));
      await deleteTask(args.task_id);
      log("Task deleted", args.task_id);
      return { success: true, message: "Task deleted" };
    }

    case "create_calendar_event": {
      const newEv = {
        id: Date.now(),
        title: args.title,
        date: args.date || today(),
        time: args.time || "10:00",
        cat: args.category || "Work"
      };
      setEv(prev => [...prev, newEv]);
      await createGoogleCalendarEvent(newEv);
      await saveCalendarEventToCloud(newEv);
      log("Calendar event created", `${newEv.title} · ${newEv.date} ${fmt(newEv.time)}`);
      return { success: true, message: `Event "${newEv.title}" scheduled on your calendar` };
    }

    case "create_recurring_schedule": {
      const rec = {
        id: Date.now(),
        title: args.title,
        date: args.date || today(),
        time: args.time || "09:00",
        pri: "Medium",
        cat: "Reminder",
        repeat: args.repeat || "daily",
        done: false
      };
      setTasks(prev => [...prev, rec]);
      await scheduleLocalReminder(rec);
      await saveTask(rec);
      log("Recurring schedule created", `${rec.title} · Repeat ${rec.repeat}`);
      return { success: true, message: `Recurring reminder created: ${rec.title} (${rec.repeat})` };
    }

    case "save_memory": {
      const newMem = {
        id: Date.now(),
        title: args.title,
        body: args.body,
        cat: args.category || "Memory"
      };
      setNotes(prev => [newMem, ...prev]);
      log("Memory saved", newMem.title);
      return { success: true, message: `Saved to memory: "${newMem.title}"` };
    }

    case "get_daily_schedule": {
      const targetDate = args.date || today();
      const dayTasks = (tasks || []).filter(t => t.date === targetDate);
      const dayEvents = (ev || []).filter(e => e.date === targetDate);
      const daySummary = `${targetDate} Schedule: ${dayTasks.length} tasks (${dayTasks.filter(t => !t.done).length} open) and ${dayEvents.length} calendar events.`;
      log("Schedule queried", daySummary);
      return { success: true, message: daySummary, data: { tasks: dayTasks, events: dayEvents } };
    }

    case "get_latest_channel_videos": {
      log("YouTube checked", "Retrieved monitored videos");
      return { success: true, message: "YouTube channels checked. See YouTube tab for latest updates." };
    }

    case "search_web": {
      log("Web searched", args.query);
      return { success: true, message: `Searched web for "${args.query}". Up-to-date results retrieved.` };
    }

    default:
      return { success: false, message: `Unsupported tool type: ${type}` };
  }
}

// Backwards compatibility alias
export const parseIntent = (text) => {
  const result = parseThanglishMultiAction(text);
  return result.actions && result.actions.length > 0 ? result.actions[0] : null;
};
