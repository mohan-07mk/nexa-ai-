export const Tgl=({on,set,l})=><div className="flex items-center justify-between py-2"><span className="text-sm">{l}</span><button className={"tog "+(on?"on":"")} aria-label={l} onClick={()=>set(!on)}/></div>;
export const Empty=({t})=><div className="card p-8 text-center mu text-sm">{t}</div>;
export const Note=({t})=><p className="text-sm p-3 rounded-xl" style={{background:"rgba(251,191,36,.1)",color:"#FBBF24"}}>{t}</p>;
