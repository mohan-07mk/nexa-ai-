// ==============================================================================
// NEXA AI — REMINDER SERVICE
// Schedules device-side reminders using Capacitor LocalNotifications,
// handles recurrence, notification actions (Mark Done, Snooze), and Supabase sync.
// ==============================================================================

import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { supabase, isSupabaseConfigured } from './supabaseClient.js';
import { getNotificationId } from './alarmService.js';
import { fmt } from '../utils/helpers.js';

export const isNative = () => Capacitor.isNativePlatform();

// Schedule a device-side local notification for a reminder
export async function scheduleLocalReminder(reminder) {
  if (reminder.done || reminder.completed) {
    await cancelLocalReminder(reminder.id);
    return;
  }

  const [year, month, day] = reminder.date.split('-').map(Number);
  const [hour, minute] = (reminder.time || '09:00').split(':').map(Number);
  const scheduledTime = new Date(year, month - 1, day, hour, minute, 0);

  if (scheduledTime.getTime() <= Date.now()) {
    // Already in the past
    return;
  }

  const notifId = getNotificationId(reminder.id);

  if (isNative()) {
    try {
      await LocalNotifications.cancel({ notifications: [{ id: notifId }] });

      // Determine recurrence interval for Capacitor if any
      let repeats = false;
      let every = undefined;
      if (reminder.repeat === 'daily') {
        repeats = true;
        every = 'day';
      } else if (reminder.repeat === 'weekly') {
        repeats = true;
        every = 'week';
      } else if (reminder.repeat === 'monthly') {
        repeats = true;
        every = 'month';
      }

      await LocalNotifications.schedule({
        notifications: [
          {
            id: notifId,
            title: `📌 Reminder: ${reminder.title}`,
            body: `Scheduled for ${fmt(reminder.time || '09:00')} · Tap to view`,
            schedule: {
              at: scheduledTime,
              repeats: repeats,
              every: every,
              allowWhileIdle: true
            },
            channelId: 'nexa-reminders',
            actionTypeId: 'REMINDER_ACTIONS',
            sound: 'beep.wav',
            extra: {
              reminderId: reminder.id,
              type: 'reminder',
              title: reminder.title,
              date: reminder.date,
              time: reminder.time
            }
          }
        ]
      });

      console.log(`Reminder scheduled for ${scheduledTime.toISOString()} ID: ${notifId}`);
    } catch (err) {
      console.warn('Failed to schedule exact local reminder, retrying without allowWhileIdle:', err);
      try {
        await LocalNotifications.schedule({
          notifications: [
            {
              id: notifId,
              title: `📌 Reminder: ${reminder.title}`,
              body: `Scheduled for ${fmt(reminder.time || '09:00')} · Tap to view`,
              schedule: {
                at: scheduledTime,
                repeats: repeats,
                every: every,
                allowWhileIdle: false
              },
              channelId: 'nexa-reminders',
              actionTypeId: 'REMINDER_ACTIONS',
              sound: 'beep.wav',
              extra: {
                reminderId: reminder.id,
                type: 'reminder',
                title: reminder.title,
                date: reminder.date,
                time: reminder.time
              }
            }
          ]
        });
      } catch (retryErr) {
        console.warn('Non-exact reminder schedule also failed:', retryErr);
      }
    }
  } else {
    // Web fallback notification timer
    const msUntil = scheduledTime.getTime() - Date.now();
    if (msUntil > 0 && msUntil < 86400000) {
      setTimeout(() => {
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification(`📌 Reminder: ${reminder.title}`, {
            body: `Due at ${fmt(reminder.time || '09:00')}`,
            icon: '/favicon.ico'
          });
        }
      }, msUntil);
    }
  }
}

// Cancel a scheduled reminder
export async function cancelLocalReminder(reminderId) {
  const notifId = getNotificationId(reminderId);
  if (isNative()) {
    try {
      await LocalNotifications.cancel({ notifications: [{ id: notifId }] });
    } catch (err) {
      console.warn('Error cancelling local reminder:', err);
    }
  }
}

// Cloud sync with Supabase
export async function saveReminderToCloud(reminder) {
  if (!isSupabaseConfigured() || !supabase) return;
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase.from('reminders').upsert({
      id: typeof reminder.id === 'string' && reminder.id.includes('-') ? reminder.id : undefined,
      user_id: user.id,
      title: reminder.title,
      date: reminder.date,
      time: reminder.time || '09:00',
      repeat: reminder.repeat || 'none',
      completed: Boolean(reminder.done || reminder.completed)
    });
  } catch (err) {
    console.warn('Cloud reminder sync error:', err);
  }
}
