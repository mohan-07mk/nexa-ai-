import React, { useState, useEffect } from 'react';
import { Ic } from '../components/Icon';
import { DN, fmt, lstr } from '../utils/helpers';
import { createGoogleCalendarEvent, saveCalendarEventToCloud, fetchGoogleCalendarEvents } from '../services/calendarService';

export default function Calendar({ ev, setEv, tasks, log }) {
  const [view, setView] = useState("Month");
  const [sel, setSel] = useState(lstr(new Date()));
  const [f, setF] = useState(null);
  const [googleConnected, setGoogleConnected] = useState(false);

  useEffect(() => {
    fetchGoogleCalendarEvents().then(items => {
      if (items && items.length > 0) {
        setGoogleConnected(true);
        // Merge Google Calendar events
        setEv(prev => {
          const map = new Map(prev.map(e => [e.id, e]));
          items.forEach(it => map.set(it.id, it));
          return Array.from(map.values());
        });
      }
    });
  }, []);

  const on = d => [
    ...ev.filter(e => e.date === d),
    ...tasks.filter(t => t.date === d).map(t => ({ id: "t" + t.id, title: t.title, time: t.time, cat: "Task", task: true }))
  ].sort((a, b) => (a.time || '').localeCompare(b.time || ''));

  const s = new Date(sel + "T00:00");
  const shift = n => {
    const d = new Date(s);
    if (view === "Month") d.setMonth(d.getMonth() + n);
    else d.setDate(d.getDate() + n * (view === "Week" ? 7 : 1));
    setSel(lstr(d));
  };

  const first = new Date(s.getFullYear(), s.getMonth(), 1);
  const cells = [
    ...Array(first.getDay()).fill(null),
    ...Array(new Date(s.getFullYear(), s.getMonth() + 1, 0).getDate()).fill(0).map((_, i) => lstr(new Date(s.getFullYear(), s.getMonth(), i + 1)))
  ];
  const wk = Array(7).fill(0).map((_, i) => {
    const d = new Date(s);
    d.setDate(s.getDate() - s.getDay() + i);
    return lstr(d);
  });

  const save = async (e) => {
    e.preventDefault();
    if (!f.title.trim()) return;

    if (f.id) {
      setEv(x => x.map(y => y.id === f.id ? f : y));
      await saveCalendarEventToCloud(f);
      log("Calendar event updated", f.title);
    } else {
      const newEv = { ...f, id: Date.now() };
      setEv(x => [...x, newEv]);
      await createGoogleCalendarEvent(newEv);
      await saveCalendarEventToCloud(newEv);
      log("Calendar event created", f.title);
    }
    setF(null);
  };

  const List = ({ d }) => {
    const it = on(d);
    return it.length === 0 ? (
      <p className="mu text-xs py-1">Nothing scheduled</p>
    ) : (
      it.map(e => (
        <div key={e.id} className="flex items-center gap-2 text-sm py-1.5" style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
          <span className="mu w-16 shrink-0 text-xs">{fmt(e.time || "09:00")}</span>
          <span className="flex-1 truncate font-medium">{e.title}</span>
          <span
            className="text-[11px] px-2 py-0.5 rounded-full"
            style={{
              background: e.task ? "rgba(34,211,238,.15)" : e.cat === "Google Calendar" ? "rgba(74,222,128,.15)" : "rgba(139,92,246,.2)",
              color: e.task ? "var(--cy)" : e.cat === "Google Calendar" ? "#4ADE80" : "var(--pu)"
            }}
          >
            {e.cat}
          </span>
          {!e.task && (
            <>
              <button className="mu text-xs hover:text-white" style={{ background: "none", border: 0 }} onClick={() => setF(e)}>Edit</button>
              <button className="mu text-xs hover:text-red-400" style={{ background: "none", border: 0 }} onClick={() => { setEv(x => x.filter(y => y.id !== e.id)); log("Calendar event deleted", e.title); }}>Delete</button>
            </>
          )}
        </div>
      ))
    );
  };

  return (
    <div className="max-w-4xl mx-auto grid gap-4">
      <div className="card p-3 flex items-center justify-between text-xs" style={{ background: "rgba(139,92,246,.1)", borderColor: "var(--pu)" }}>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: googleConnected ? "#4ADE80" : "#FBBF24" }} />
          <span>{googleConnected ? "Google Calendar Synced via OAuth" : "Local & Supabase Synced · Tasks automatically shown"}</span>
        </div>
        <span className="mu text-xs">UTC+05:30 (IST)</span>
      </div>

      <div className="flex flex-wrap gap-2 items-center">
        {["Month", "Week", "Day"].map(v => (
          <button
            key={v}
            className="btn"
            style={view === v ? { background: "rgba(139,92,246,.2)", borderColor: "var(--pu)" } : {}}
            onClick={() => setView(v)}
          >
            {v}
          </button>
        ))}
        <button className="btn" aria-label="Previous" onClick={() => shift(-1)}>‹</button>
        <span className="font-bold text-sm">
          {s.toLocaleDateString(undefined, { month: "long", year: "numeric", ...(view === "Day" ? { day: "numeric" } : {}) })}
        </span>
        <button className="btn" aria-label="Next" onClick={() => shift(1)}>›</button>
        <button className="btn btn-p ml-auto" onClick={() => setF({ title: "", date: sel, time: "10:00", cat: "Work" })}>
          Add event
        </button>
      </div>

      {f && (
        <form onSubmit={save} className="card p-4 flex flex-wrap gap-2">
          <input className="inp flex-1 min-w-[160px]" placeholder="Event title" value={f.title} onChange={e => setF({ ...f, title: e.target.value })} />
          <input className="inp" type="date" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} />
          <input className="inp" type="time" value={f.time} onChange={e => setF({ ...f, time: e.target.value })} />
          <select className="inp" value={f.cat} onChange={e => setF({ ...f, cat: e.target.value })}>
            {["Work", "Personal", "Health", "Study"].map(c => <option key={c}>{c}</option>)}
          </select>
          <button className="btn btn-p" type="submit">Save event</button>
          <button type="button" className="btn" onClick={() => setF(null)}>Cancel</button>
        </form>
      )}

      {view === "Month" && (
        <div className="card p-3">
          <div className="grid grid-cols-7 gap-1 text-center text-xs mu mb-1">
            {DN.map((d, i) => <span key={i}>{d}</span>)}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {cells.map((d, i) => d ? (
              <button
                key={i}
                onClick={() => setSel(d)}
                className="aspect-square rounded-xl text-sm relative transition-all"
                style={{
                  border: "1px solid " + (d === sel ? "var(--pu)" : "var(--line)"),
                  background: d === lstr(new Date()) ? "rgba(139,92,246,.2)" : "var(--bg2)",
                  color: "var(--tx)"
                }}
              >
                {+d.slice(8)}
                {on(d).length > 0 && (
                  <span className="absolute bottom-1.5 left-1/2 w-1.5 h-1.5 rounded-full" style={{ background: "var(--cy)", transform: "translateX(-50%)" }} />
                )}
              </button>
            ) : (
              <span key={i} />
            ))}
          </div>
        </div>
      )}

      {view === "Week" && (
        <div className="grid gap-2">
          {wk.map(d => (
            <div key={d} className="card p-3">
              <p className="text-xs font-bold" style={{ color: d === lstr(new Date()) ? "var(--cy)" : "var(--mu)" }}>
                {new Date(d + "T00:00").toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "short" })}
              </p>
              <List d={d} />
            </div>
          ))}
        </div>
      )}

      {view !== "Week" && (
        <section className="card p-4">
          <h3 className="font-bold mb-2">
            {s.toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long" })}
          </h3>
          <List d={sel} />
        </section>
      )}
    </div>
  );
}
