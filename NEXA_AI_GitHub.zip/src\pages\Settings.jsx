import React, { useState, useEffect } from 'react';
import { Tgl } from '../components/ui';
import { isSupabaseConfigured, signInWithGoogle, signOutUser, getCurrentUser } from '../services/supabaseClient';
import { isNative, requestNotificationPermission } from '../services/notificationService';

export default function Settings({ set, setSet, setTasks, setAlarms, setNotes, setEv, setYt, setAutos }) {
  const u = (k, v) => setSet(s => ({ ...s, [k]: v }));
  const Sec = ({ t, children }) => (
    <section className="card p-4">
      <h3 className="font-bold mb-2">{t}</h3>
      {children}
    </section>
  );

  const [msg, setMsg] = useState("");
  const [currentUser, setCurrentUser] = useState(null);
  const [notifGranted, setNotifGranted] = useState(false);

  useEffect(() => {
    getCurrentUser().then(setCurrentUser);
  }, []);

  const handleGoogleLogin = async () => {
    try {
      await signInWithGoogle();
    } catch (err) {
      setMsg(err.message || "Failed to sign in with Google.");
    }
  };

  const handleLogout = async () => {
    try {
      await signOutUser();
      setCurrentUser(null);
      setMsg("Signed out successfully.");
    } catch (err) {
      setMsg("Signed out.");
    }
  };

  const enableNotifications = async () => {
    const granted = await requestNotificationPermission();
    setNotifGranted(granted);
    setMsg(granted ? "Notification permissions granted." : "Notification permission denied or blocked.");
  };

  const integrations = [
    { name: "Supabase Cloud DB", status: isSupabaseConfigured() ? "Connected · RLS Active" : "Configured via .env" },
    { name: "Gemini AI Agent", status: "Enabled · 18 Tools & Thanglish Engine" },
    { name: "Android AlarmManager", status: isNative() ? "Native Android Active" : "Web Preview Mode" },
    { name: "YouTube Monitor", status: "Zero-Quota RSS & API Ready" },
    { name: "Google Calendar", status: currentUser ? "Synced via Google OAuth" : "Local Sync Ready" },
    { name: "FCM Push Notifications", status: isNative() ? "Device Token Registered" : "Web Local Mode" }
  ];

  return (
    <div className="max-w-3xl mx-auto grid gap-4">
      {/* Profile & Auth */}
      <Sec t="Profile & Authentication">
        <div className="grid sm:grid-cols-2 gap-2 mb-3">
          <input className="inp" aria-label="Name" value={set.name} onChange={e => u("name", e.target.value)} placeholder="Your Name" />
          <input className="inp" aria-label="Email" type="email" value={set.email} onChange={e => u("email", e.target.value)} placeholder="Email" />
        </div>

        {currentUser ? (
          <div className="flex items-center justify-between p-3 rounded-xl" style={{ background: "rgba(74,222,128,0.1)", border: "1px solid #4ADE80" }}>
            <span className="text-xs">Signed in as <strong>{currentUser.email}</strong></span>
            <button className="btn text-xs py-1" onClick={handleLogout}>Log out</button>
          </div>
        ) : (
          <div className="flex flex-wrap gap-2 items-center">
            <button className="btn btn-p text-xs" onClick={handleGoogleLogin}>Sign in with Google</button>
            <span className="mu text-xs">Syncs Google Calendar & YouTube Subscriptions</span>
          </div>
        )}
      </Sec>

      {/* AI Assistant Preferences */}
      <Sec t="AI Agent Settings">
        <div className="grid sm:grid-cols-2 gap-2">
          <div>
            <label className="mu text-xs block mb-1">Response Language</label>
            <select className="inp w-full" aria-label="Response language" value={set.lang} onChange={e => u("lang", e.target.value)}>
              {["Thanglish", "English", "Tamil"].map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="mu text-xs block mb-1">AI Engine Model</label>
            <select className="inp w-full" aria-label="Model" value={set.model} onChange={e => u("model", e.target.value)}>
              {["Gemini 1.5 Flash (Recommended)", "Gemini 1.5 Pro", "Built-in Thanglish Engine"].map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
        </div>
        <p className="text-xs mu mt-2">
          NEXA AI understands Tamil spoken or written in Thanglish script (*"Naalaiku morning 6 mani alarm vai"*), Tamil script, and English.
        </p>
        <Tgl l="Enable Personal Memory" on={set.memory} set={v => u("memory", v)} />
      </Sec>

      {/* Notifications */}
      <Sec t="Notification Permissions & Channels">
        <div className="mb-2">
          <button className="btn btn-p text-xs py-1.5" onClick={enableNotifications}>
            Request Android Notification Permission
          </button>
        </div>
        {[
          ["nReminders", "Reminder notifications (High Priority)"],
          ["nYt", "YouTube video alerts"],
          ["nDaily", "Daily AI morning briefing"],
          ["nAuto", "Automation routine executions"]
        ].map(([k, l]) => (
          <Tgl key={k} l={l} on={set[k]} set={v => u(k, v)} />
        ))}
      </Sec>

      {/* Live Integrations Status */}
      <Sec t="System Integrations & Architecture">
        {integrations.map(it => (
          <div key={it.name} className="flex items-center justify-between py-2 text-sm" style={{ borderTop: "1px solid var(--line)" }}>
            <span className="font-medium">{it.name}</span>
            <span className="text-xs" style={{ color: "#4ADE80" }}>{it.status}</span>
          </div>
        ))}
        <p className="text-xs mu mt-2">
          Security architecture: API keys and sensitive tokens are handled strictly server-side via Supabase Edge Functions.
        </p>
      </Sec>

      {/* Privacy & Reset */}
      <Sec t="Privacy & Data Management">
        <div className="flex flex-wrap gap-2">
          <button
            className="btn text-xs hover:border-red-500"
            onClick={() => {
              if (confirm("Reset all local cache and memories?")) {
                [setTasks, setAlarms, setNotes, setEv, setYt, setAutos].forEach(f => f([]));
                try {
                  localStorage.removeItem("nexa.convos");
                  localStorage.removeItem("nexa.act");
                } catch (e) {}
                setMsg("All local data reset. Reload to start fresh.");
              }
            }}
          >
            Clear Local Data
          </button>
        </div>
        {msg && <p className="text-xs mt-2" style={{ color: "#FBBF24" }}>{msg}</p>}
      </Sec>
    </div>
  );
}
