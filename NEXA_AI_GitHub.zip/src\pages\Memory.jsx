import React, { useState } from 'react';
import { Empty } from '../components/ui';
import { supabase, isSupabaseConfigured } from '../services/supabaseClient';

export default function Memory({ notes, setNotes, log, set }) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const [f, setF] = useState({ title: "", body: "", cat: "Note" });
  const CATS = ["Note", "Memory", "Preference", "Important"];

  const list = notes.filter(n =>
    (cat === "All" || n.cat === cat) &&
    (n.title + " " + n.body).toLowerCase().includes(q.toLowerCase())
  );

  const save = async (e) => {
    e.preventDefault();
    if (!f.title.trim()) return;

    if (f.id) {
      setNotes(x => x.map(y => y.id === f.id ? f : y));
      log("Memory updated", f.title);
    } else {
      const newNote = { ...f, id: Date.now() };
      setNotes(x => [newNote, ...x]);
      log("Memory saved", f.title);

      // Cloud sync
      if (isSupabaseConfigured() && supabase) {
        try {
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
            await supabase.from('memories').insert({
              user_id: user.id,
              title: f.title,
              body: f.body,
              category: f.cat === "Note" ? "Note" : f.cat
            });
          }
        } catch (err) {
          console.warn('Memory sync error:', err);
        }
      }
    }
    setF({ title: "", body: "", cat: "Note" });
  };

  const remove = (id, title) => {
    setNotes(x => x.filter(y => y.id !== id));
    log("Memory deleted", title);
  };

  return (
    <div className="max-w-3xl mx-auto grid gap-4">
      <div className="card p-3 flex items-center justify-between text-xs" style={{ background: "rgba(139,92,246,.1)", borderColor: "var(--pu)" }}>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: "#4ADE80" }} />
          <span>{set.memory ? "Long-Term Memory Active · Used by NEXA AI Agent" : "Memory paused in Settings"}</span>
        </div>
        <span className="mu text-xs">User privacy protected</span>
      </div>

      <form onSubmit={save} className="card p-4 grid gap-2">
        <div className="flex gap-2 flex-wrap">
          <input
            className="inp flex-1 min-w-[160px]"
            placeholder="Title (e.g. Favorite foods or Daily work routine)"
            value={f.title}
            onChange={e => setF({ ...f, title: e.target.value })}
          />
          <select className="inp" value={f.cat} onChange={e => setF({ ...f, cat: e.target.value })}>
            {CATS.map(c => <option key={c}>{c}</option>)}
          </select>
        </div>
        <textarea
          className="inp"
          rows="2"
          placeholder="Details or preferences…"
          value={f.body}
          onChange={e => setF({ ...f, body: e.target.value })}
        />
        <div className="flex gap-2">
          <button className="btn btn-p" type="submit">{f.id ? "Save changes" : "Add to memory"}</button>
          {f.id && <button type="button" className="btn" onClick={() => setF({ title: "", body: "", cat: "Note" })}>Cancel</button>}
        </div>
      </form>

      <div className="flex flex-wrap gap-2">
        {["All", ...CATS].map(c => (
          <button
            key={c}
            className="btn"
            style={cat === c ? { background: "rgba(139,92,246,.2)", borderColor: "var(--pu)" } : {}}
            onClick={() => setCat(c)}
          >
            {c}
          </button>
        ))}
        <input className="inp flex-1 min-w-[140px]" placeholder="Search memories & notes…" value={q} onChange={e => setQ(e.target.value)} />
      </div>

      {list.length === 0 && <Empty t="Nothing found. Add a note or memory above." />}

      {list.map(n => (
        <div key={n.id} className="card p-4">
          <div className="flex items-center gap-2">
            <p className="font-bold text-sm flex-1">{n.title}</p>
            <span className="text-[11px] px-2 py-0.5 rounded-full" style={{ background: "rgba(139,92,246,.2)" }}>
              {n.cat}
            </span>
          </div>
          <p className="text-sm mu mt-1.5" style={{ overflowWrap: "anywhere" }}>{n.body}</p>
          <div className="flex gap-3 mt-3 pt-2" style={{ borderTop: "1px solid var(--line)" }}>
            <button className="mu text-xs hover:text-white" style={{ background: "none", border: 0 }} onClick={() => setF(n)}>Edit</button>
            <button className="mu text-xs hover:text-red-400" style={{ background: "none", border: 0 }} onClick={() => remove(n.id, n.title)}>Delete</button>
          </div>
        </div>
      ))}
    </div>
  );
}
