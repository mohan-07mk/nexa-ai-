import React, { useState } from 'react';
import { Ic } from '../components/Icon';
import { Tgl, Empty, Note } from '../components/ui';
import { parseYouTubeInput, fetchChannelLatestVideo, triggerYouTubeMonitorCheck, saveChannelToCloud } from '../services/youtubeService';

export default function YouTube({ yt, setYt, log }) {
  const [url, setUrl] = useState("");
  const [q, setQ] = useState("");
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const add = async (e) => {
    e.preventDefault();
    if (!url.trim()) return;

    setLoading(true);
    setMsg("Detecting channel and fetching latest video…");

    try {
      const parsed = parseYouTubeInput(url);
      const videoInfo = await fetchChannelLatestVideo(url);

      const newChannel = {
        id: Date.now(),
        name: parsed.channelName,
        url: parsed.url,
        channelId: parsed.channelId,
        notify: true,
        video: videoInfo
      };

      setYt(c => [newChannel, ...c]);
      await saveChannelToCloud(newChannel);
      log("Channel added", `${parsed.channelName} · Latest: ${videoInfo.title}`);
      setUrl("");
      setMsg("");
    } catch (err) {
      setMsg("Could not fetch channel. Check the URL or handle.");
    } finally {
      setLoading(false);
    }
  };

  const refreshAll = async () => {
    setLoading(true);
    setMsg("Checking all monitored channels for new uploads…");
    try {
      const res = await triggerYouTubeMonitorCheck();
      // Also update latest video for each active channel locally
      const updatedList = await Promise.all(yt.map(async (ch) => {
        try {
          const v = await fetchChannelLatestVideo(ch.url || ch.name);
          return { ...ch, video: v };
        } catch (_) {
          return ch;
        }
      }));
      setYt(updatedList);
      setMsg(res.message || "Channels updated successfully.");
      log("YouTube check", `Refreshed ${yt.length} channels`, "Success");
    } catch (err) {
      setMsg("Refresh complete.");
    } finally {
      setLoading(false);
    }
  };

  const removeChannel = (id, name) => {
    setYt(x => x.filter(y => y.id !== id));
    log("Channel removed", name);
  };

  const chs = yt.filter(c => c.name.toLowerCase().includes(q.toLowerCase()));
  const feed = yt.filter(c => c.video).sort((a, b) => (b.video?.date || '').localeCompare(a.video?.date || ''));
  const href = c => c.url.startsWith("http") ? c.url : "https://" + c.url;

  return (
    <div className="max-w-4xl mx-auto grid gap-4">
      <div className="card p-3 flex items-center justify-between text-xs" style={{ background: "rgba(34,211,238,.08)", borderColor: "var(--cy)" }}>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: "#22D3EE" }} />
          <span>YouTube Monitor Active · Real-time RSS feeds & Supabase Cloud Scheduler</span>
        </div>
        <button className="btn text-xs py-1 px-3 flex items-center gap-1.5" onClick={refreshAll} disabled={loading}>
          <Ic n="refresh" s={13} /> {loading ? "Checking…" : "Check New Videos"}
        </button>
      </div>

      <form onSubmit={add} className="card p-4 flex gap-2 flex-wrap">
        <input
          className="inp flex-1 min-w-[200px]"
          placeholder="youtube.com/@channel, handle, or channel ID"
          value={url}
          onChange={e => setUrl(e.target.value)}
          disabled={loading}
        />
        <button className="btn btn-p" type="submit" disabled={loading}>
          {loading ? "Adding…" : "Add channel"}
        </button>
        {msg && <p className="w-full text-xs mt-1" style={{ color: "#FBBF24" }}>{msg}</p>}
      </form>

      <input className="inp" placeholder="Search monitored channels…" value={q} onChange={e => setQ(e.target.value)} />

      <div className="grid sm:grid-cols-2 gap-3">
        {chs.length === 0 && <Empty t="No channels monitored yet. Add one above." />}
        {chs.map(c => (
          <div key={c.id} className="card p-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center font-extrabold shrink-0"
                  style={{ background: "linear-gradient(135deg,var(--pu),var(--cy))", color: "#08090D" }}
                >
                  {c.name[0]?.toUpperCase() || "Y"}
                </div>
                <div className="flex-1 min-w-0">
                  <a className="font-bold text-sm truncate block hover:underline" href={href(c)} target="_blank" rel="noreferrer">
                    {c.name}
                  </a>
                  <p className="text-xs mu">{c.video ? `Latest: ${c.video.date}` : "Checking for uploads…"}</p>
                </div>
                {c.video && c.video.isNew && (
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full" style={{ background: "rgba(34,211,238,.15)", color: "var(--cy)" }}>
                    New
                  </span>
                )}
              </div>

              {c.video && (
                <div className="mt-3 p-2.5 rounded-xl flex gap-3 items-center" style={{ background: "var(--bg2)" }}>
                  {c.video.thumbnail && (
                    <img
                      src={c.video.thumbnail}
                      alt={c.video.title}
                      className="w-16 h-12 object-cover rounded-lg shrink-0"
                    />
                  )}
                  <a
                    href={c.video.url}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs font-semibold line-clamp-2 hover:text-[var(--cy)]"
                  >
                    {c.video.title}
                  </a>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between mt-3 pt-2" style={{ borderTop: "1px solid var(--line)" }}>
              <Tgl
                l="FCM Alerts"
                on={c.notify}
                set={v => setYt(x => x.map(y => y.id === c.id ? { ...y, notify: v } : y))}
              />
              <button
                className="mu text-xs hover:text-red-400"
                style={{ background: "none", border: 0 }}
                onClick={() => removeChannel(c.id, c.name)}
              >
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>

      <section className="card p-4">
        <h3 className="font-bold mb-2">Recent Channel Uploads</h3>
        {feed.length === 0 && <p className="mu text-sm">No videos tracked yet.</p>}
        {feed.map(c => (
          <div key={c.id} className="text-sm py-2 flex items-center justify-between gap-3" style={{ borderTop: "1px solid var(--line)" }}>
            <a href={c.video.url} target="_blank" rel="noreferrer" className="truncate hover:underline">
              {c.video.title}
            </a>
            <span className="mu shrink-0 text-xs">{c.name} · {c.video.date}</span>
          </div>
        ))}
      </section>
    </div>
  );
}
